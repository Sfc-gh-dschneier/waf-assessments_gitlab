# WAF Assessment Notebooks

Automated Well-Architected Framework (WAF) assessment notebooks for Snowflake accounts using DDM (Data Domain Model) as the single source of truth.

## Overview

These notebooks provide automated analysis of Snowflake account configurations against WAF best practices across all five pillars:

| Notebook | Pillar | Key Assessments |
|----------|--------|-----------------|
| `01-operational-excellence-audit.ipynb` | Operational Excellence | IaC adoption, Git integration, task health, alerts, time travel, naming conventions |
| `02-security-audit.ipynb` | Security | Authentication, MFA, RBAC, data protection policies, network security |
| `03-reliability-audit.ipynb` | Reliability | Task automation, multi-cluster HA, disaster recovery, streams, alerting |
| `04-performance-efficiency-audit.ipynb` | Performance Efficiency | Query performance, clustering strategy, QAS, materialized views, dynamic tables |
| `05-cost-optimization-audit.ipynb` | Cost Optimization | Resource monitors, warehouse config, auto-clustering, cost attribution tags |

### Data Source

All notebooks query **SNOWHOUSE_IMPORT** ETL_V views (DDM) rather than customer ACCOUNT_USAGE views, enabling:
- Cross-account analysis without customer access
- Consistent data model across all assessments
- Historical configuration tracking

## Prerequisites

- **Cortex Code (CoCo) Desktop** installed
- **Snowflake connection** configured with access to SNOWHOUSE_IMPORT database
- **Python 3.8+** with Snowpark support

## Setup Instructions

### 1. Configure Snowflake Connection

Ensure you have a connection named `snowhouse` configured in CoCo Desktop:

```bash
# List available connections
snow connection list

# Or add a new connection
snow connection add
```

### 2. Install Dependencies

```bash
cd Common/Notebook/WAF_Assessment
pip install -r requirements.txt
```

Required packages:
- `snowflake-snowpark-python`
- `snowflake-connector-python[pandas]`
- `pandas`

### 3. Configure Target Account

In each notebook, update **Cell 2** with your target account details:

```python
SCHEMA = "IE"          # Deployment schema (IE, AU, PROD, VA, etc.)
ACCOUNT_ID = 100058    # Target Snowflake account ID
DATABASE = "SNOWHOUSE_IMPORT"
```

### 4. Run Notebooks

**Option A: CoCo Desktop (Recommended)**
1. Open the notebook in CoCo Desktop
2. Run Cell 2 (Configuration)
3. Run Cell 3 (Session creation) - creates session only if not already exists
4. Run remaining cells sequentially

**Option B: Snowsight Notebooks**
1. Upload notebook to Snowflake
2. In Cell 2, uncomment the Snowsight session block
3. Comment out the CoCo Desktop session block in Cell 3
4. Run all cells

## Notebook Structure

Each notebook follows a consistent structure:

```
Cell 0-1:  Title and setup header
Cell 2:    Configuration (SCHEMA, ACCOUNT_ID, DATABASE)
Cell 3:    Session creation (conditional - won't recreate if exists)
Cell 4:    Cache data header
Cell 5:    Create temporary cache tables from ETL_V views
Cell 6+:   Assessment sections with scoring
Final:     Summary with overall pillar score
```

## Pillar-Specific Notes

### 01 - Operational Excellence
- Detects IaC tools (Terraform, Pulumi, Snowflake CLI) from query history
- Analyzes Git integration usage
- Checks naming convention consistency

### 02 - Security
- Requires access to authentication event data
- Analyzes MFA adoption and password policies
- Reviews RBAC configuration and overly permissive grants

### 03 - Reliability
- Focuses on business continuity and DR readiness
- Scores replication/failover group configuration
- Analyzes multi-cluster warehouse setup for HA

### 04 - Performance Efficiency
- Identifies slow queries (>60 seconds)
- Analyzes clustering strategy gaps
- Focuses on MV validity for performance impact

### 05 - Cost Optimization
- Comprehensive resource monitor WAF analysis (5 best practices)
- Auto-clustering best practices (column count, key definition)
- Warehouse auto-suspend checks
- Cost attribution tag coverage

## Output

Each notebook produces:
- Detailed assessment output for each best practice
- Individual scores per assessment area
- Overall pillar score (0-100%)
- Priority improvement recommendations

Example summary output:
```
OPERATIONAL EXCELLENCE - OVERALL ASSESSMENT SUMMARY
======================================================================
Target: SNOWHOUSE_IMPORT.IE | Account ID: 100058

Operational Excellence Scores:
--------------------------------------------------
 1. Infrastructure as Code (IaC): 75%
 2. Git Integration: 100%
 3. Task Health: 50%
...

OVERALL OPERATIONAL EXCELLENCE SCORE: 72%
Rating: GOOD - Solid foundation with room for improvement
```

## Documentation

Detailed WAF guidance for each pillar is available in the `docs/` folder:
- `docs/01-operational-excellence.md`
- `docs/02-security.md`
- `docs/03-reliability.md`
- `docs/04-performance-efficiency.md`
- `docs/05-cost-optimization.md`

## Troubleshooting

### Session already exists error
The notebooks use conditional session creation. If you encounter issues, restart the kernel:
```python
# Notebooks use this pattern to avoid recreating sessions:
if 'session' not in globals():
    session = Session.builder.config("connection_name", connection_name).create()
```

### Column not found errors
ETL_V views may differ from ACCOUNT_USAGE views. The notebooks are designed for DDM ETL_V schema. If you encounter column errors, verify you're querying the correct database/schema.

### Connection issues
```bash
# Verify connection
snow connection test -c snowhouse

# Check environment variable
echo $SNOWFLAKE_CONNECTION_NAME
```

## Contributing

When adding new assessments:
1. Add metrics to the appropriate pillar notebook
2. Update the summary scoring in the final cell
3. Update this README if adding new dependencies or setup steps
