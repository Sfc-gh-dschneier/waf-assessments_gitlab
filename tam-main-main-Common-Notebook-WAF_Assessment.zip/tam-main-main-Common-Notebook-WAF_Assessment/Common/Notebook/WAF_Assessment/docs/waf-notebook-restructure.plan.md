---
name: "waf-notebook-restructure"
created: "2026-01-29T09:43:17.156Z"
status: pending
---

# WAF Notebook Restructure Plan

## Overview

Update each of the 5 WAF assessment notebooks to center around the new **Key Topics** structure (from the updated MD files) instead of the old **Core Principles** structure. For each topic and sub-topic, identify whether it can be assessed using DDM data or requires manual assessment questions.

---

## Current State vs Target State

| Notebook                  | Current Structure | Target Structure                                                |
| ------------------------- | ----------------- | --------------------------------------------------------------- |
| 01-Operational Excellence | 5 Principles      | 4 Key Topics: Prepare, Implement, Collaborate, Automate         |
| 02-Security               | Principles-based  | 4 Key Topics: Secure, Govern, Comply, Monitor                   |
| 03-Reliability            | Principles-based  | 4 Key Topics: Governance, Tolerance, Resiliency, Recovery       |
| 04-Performance            | Principles-based  | 4 Key Topics: Maximize, Scale, Improve, Leverage                |
| 05-Cost Optimization      | Principles-based  | 4 Key Topics: Business Value, Visibility, Control, Optimization |

---

## Available DDM Views

The following ETL\_V views are available for automated assessment:

| View                      | Data Available                        |
| ------------------------- | ------------------------------------- |
| `JOB_ETL_V`               | Job/pipeline execution data           |
| `SESSION_ETL_V`           | Session metadata, client applications |
| `STAGE_ETL_V`             | Stages including Git repositories     |
| `DATABASE_ETL_V`          | Databases, retention settings         |
| `WAREHOUSE_ETL_V`         | Warehouse config, auto-suspend, MCW   |
| `RESOURCE_MONITOR_ETL_V`  | Resource monitor configuration        |
| `REPLICATION_GROUP_ETL_V` | Replication/failover groups           |
| `ALERT_ETL_V`             | Alert configurations                  |
| `STREAM_ETL_V`            | CDC streams                           |
| `USER_TASK_ETL_V`         | Tasks configuration                   |
| `FUNCTION_ETL_V`          | UDFs and Stored Procedures            |
| `TABLE_ETL_V`             | Tables, clustering, dynamic tables    |
| `USER_ETL_V`              | Users, MFA, authentication            |
| `INTEGRATION_ETL_V`       | Security integrations (SSO)           |
| `NETWORK_POLICY_ETL_V`    | Network policies                      |
| `POLICY_ETL_V`            | Masking/Row Access policies           |
| `TAG_ETL_V`               | Object tags                           |
| `GRANT_REC_ETL_V`         | Role grants                           |
| `PIPE_ETL_V`              | Snowpipe configurations               |

---

## Notebook 1: Operational Excellence

### Key Topic: PREPARE (Set the foundation for operational success)

| Sub-Topic                | DDM Assessable? | DDM Views                                          | Manual Assessment Questions                                                                                                           |
| ------------------------ | --------------- | -------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| **Data Modeling**        | ⚠️ Partial      | `TABLE_ETL_V` - can detect table types             | - Is there a documented data modeling approach (Star Schema, Data Vault, etc.)? - Are modeling standards enforced during code review? |
| **Naming Conventions**   | ✅ Yes           | `DATABASE_ETL_V`, `TABLE_ETL_V`, `WAREHOUSE_ETL_V` | Can analyze naming patterns programmatically                                                                                          |
| **Environment Strategy** | ✅ Yes           | `DATABASE_ETL_V` - detect DEV/TEST/PROD patterns   | - Is there a documented promotion process between environments?                                                                       |
| **Capacity Planning**    | ⚠️ Partial      | `RESOURCE_MONITOR_ETL_V`, `WAREHOUSE_ETL_V`        | - Is capacity planning performed before major projects? - Are growth forecasts reviewed quarterly?                                    |

### Key Topic: IMPLEMENT (Deploy with consistency and repeatability)

| Sub-Topic                  | DDM Assessable? | DDM Views                                                                | Manual Assessment Questions                                                                                  |
| -------------------------- | --------------- | ------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------ |
| **Infrastructure as Code** | ✅ Yes           | `SESSION_ETL_V` - CLIENT\_APPLICATION\_ID patterns (Terraform, CLI, dbt) | None - fully automated                                                                                       |
| **CI/CD Pipelines**        | ⚠️ Partial      | `STAGE_ETL_V` - Git stages, `SESSION_ETL_V` - client apps                | - Are deployment pipelines automated (GitHub Actions, Azure DevOps)? - Are deployments gated with approvals? |
| **Version Control**        | ✅ Yes           | `STAGE_ETL_V` - Git repository stages                                    | None - fully automated                                                                                       |
| **Schema Migration**       | ⚠️ Partial      | `SESSION_ETL_V` - Schemachange/Flyway detection                          | - Are schema changes tracked in migration scripts? - Is there a rollback procedure?                          |

### Key Topic: COLLABORATE (Enable team effectiveness)

| Sub-Topic                    | DDM Assessable? | DDM Views                    | Manual Assessment Questions                                                                                                       |
| ---------------------------- | --------------- | ---------------------------- | --------------------------------------------------------------------------------------------------------------------------------- |
| **Documentation**            | ❌ No            | N/A                          | - Are data dictionaries maintained? - Is there lineage documentation? - Are runbooks documented for incidents?                    |
| **Standards**                | ❌ No            | N/A                          | - Are SQL coding standards published? - Is there a code review process? - Are approval workflows in place for production changes? |
| **Cross-Team Communication** | ⚠️ Partial      | `TAG_ETL_V` - ownership tags | - Is there clear ownership for data assets? - Are communication channels established between teams?                               |

### Key Topic: AUTOMATE (Reduce manual toil and human error)

| Sub-Topic           | DDM Assessable? | DDM Views                                                         | Manual Assessment Questions                                                                |
| ------------------- | --------------- | ----------------------------------------------------------------- | ------------------------------------------------------------------------------------------ |
| **Task Scheduling** | ✅ Yes           | `USER_TASK_ETL_V`, `STREAM_ETL_V`, `TABLE_ETL_V` (Dynamic Tables) | None - fully automated                                                                     |
| **Alerting**        | ✅ Yes           | `ALERT_ETL_V`, `RESOURCE_MONITOR_ETL_V`                           | None - fully automated                                                                     |
| **Self-Healing**    | ⚠️ Partial      | `USER_TASK_ETL_V` - retry config, timeout settings                | - Is there retry logic for transient failures? - Are error handling patterns standardized? |

---

## Notebook 2: Security

### Key Topic: SECURE (Protect access to your Snowflake environment)

| Sub-Topic            | DDM Assessable? | DDM Views                                          | Manual Assessment Questions                   |
| -------------------- | --------------- | -------------------------------------------------- | --------------------------------------------- |
| **Authentication**   | ✅ Yes           | `USER_ETL_V` - MFA, `INTEGRATION_ETL_V` - SSO/SAML | - Are service account passwords rotated?      |
| **Network Security** | ✅ Yes           | `NETWORK_POLICY_ETL_V`                             | - Is Private Link configured for production?  |
| **Encryption**       | ⚠️ Partial      | N/A (Snowflake default)                            | - Is Tri-Secret Secure needed for compliance? |

### Key Topic: GOVERN (Control who can access what data)

| Sub-Topic               | DDM Assessable? | DDM Views                                    | Manual Assessment Questions              |
| ----------------------- | --------------- | -------------------------------------------- | ---------------------------------------- |
| **Access Control**      | ✅ Yes           | `GRANT_REC_ETL_V` - role hierarchy           | None - fully automated                   |
| **Data Classification** | ✅ Yes           | `TAG_ETL_V` - classification tags            | - Is data classification policy defined? |
| **Data Protection**     | ✅ Yes           | `POLICY_ETL_V` - masking/row access policies | None - fully automated                   |

### Key Topic: COMPLY (Meet regulatory and audit requirements)

| Sub-Topic          | DDM Assessable? | DDM Views                              | Manual Assessment Questions                                                               |
| ------------------ | --------------- | -------------------------------------- | ----------------------------------------------------------------------------------------- |
| **Audit Logging**  | ⚠️ Partial      | Query history available but not in DDM | - Is Access History being monitored? - What is the audit log retention period?            |
| **Data Residency** | ❌ No            | N/A                                    | - Are data sovereignty requirements met? - Are cross-region replication policies defined? |
| **Trust Center**   | ❌ No            | N/A                                    | - Is Trust Center reviewed regularly? - Are security recommendations acted upon?          |

### Key Topic: MONITOR (Detect and respond to security events)

| Sub-Topic               | DDM Assessable? | DDM Views     | Manual Assessment Questions                                                    |
| ----------------------- | --------------- | ------------- | ------------------------------------------------------------------------------ |
| **Security Dashboards** | ❌ No            | N/A           | - Are security dashboards built and reviewed?                                  |
| **Alerting**            | ✅ Yes           | `ALERT_ETL_V` | - Are alerts set for failed logins? - Are privilege escalations monitored?     |
| **SIEM Integration**    | ❌ No            | N/A           | - Is there SIEM integration? - Are security events exported to external tools? |

---

## Notebook 3: Reliability

### Key Topic: GOVERNANCE (Establish reliability standards and ownership)

| Sub-Topic                  | DDM Assessable? | DDM Views                               | Manual Assessment Questions                                                                 |
| -------------------------- | --------------- | --------------------------------------- | ------------------------------------------------------------------------------------------- |
| **SLA Definition**         | ❌ No            | N/A                                     | - Are SLAs (RTO/RPO) defined for critical workloads? - Are workloads tiered by criticality? |
| **Ownership Model**        | ⚠️ Partial      | `TAG_ETL_V` - ownership tags            | - Is there clear ownership for data assets? - Is there an on-call rotation?                 |
| **Operational Procedures** | ❌ No            | N/A                                     | - Are runbooks documented? - Are escalation paths defined?                                  |
| **Change Management**      | ⚠️ Partial      | `DATABASE_ETL_V` - Time Travel settings | - Are approval workflows in place? - Is there a rollback procedure?                         |

### Key Topic: TOLERANCE (Handle expected failures gracefully)

| Sub-Topic                 | DDM Assessable? | DDM Views                          | Manual Assessment Questions                                                          |
| ------------------------- | --------------- | ---------------------------------- | ------------------------------------------------------------------------------------ |
| **Retry Logic**           | ⚠️ Partial      | `USER_TASK_ETL_V` - retry settings | - Is exponential backoff implemented? - Are transient errors handled?                |
| **Idempotent Operations** | ❌ No            | N/A                                | - Are pipelines designed for re-run safety? - Are MERGE statements used for upserts? |
| **Graceful Degradation**  | ❌ No            | N/A                                | - Do systems continue with reduced capability on failure?                            |
| **Circuit Breakers**      | ❌ No            | N/A                                | - Are circuit breaker patterns implemented?                                          |

### Key Topic: RESILIENCY (Architect for high availability)

| Sub-Topic                   | DDM Assessable? | DDM Views                               | Manual Assessment Questions   |
| --------------------------- | --------------- | --------------------------------------- | ----------------------------- |
| **Multi-Region Deployment** | ✅ Yes           | `REPLICATION_GROUP_ETL_V`               | None - fully automated        |
| **Client Redirect**         | ⚠️ Partial      | `REPLICATION_GROUP_ETL_V`               | - Is Client Redirect enabled? |
| **Workload Isolation**      | ✅ Yes           | `WAREHOUSE_ETL_V` - separate warehouses | None - fully automated        |
| **Load Distribution**       | ✅ Yes           | `WAREHOUSE_ETL_V` - MCW config          | None - fully automated        |

### Key Topic: RECOVERY (Restore operations quickly after failures)

| Sub-Topic                     | DDM Assessable? | DDM Views                             | Manual Assessment Questions                                     |
| ----------------------------- | --------------- | ------------------------------------- | --------------------------------------------------------------- |
| **Time Travel**               | ✅ Yes           | `DATABASE_ETL_V` - retention settings | None - fully automated                                          |
| **Fail-safe**                 | ⚠️ Partial      | Inherent to Snowflake                 | - Is Fail-safe understood and documented?                       |
| **Backup Strategy**           | ⚠️ Partial      | `REPLICATION_GROUP_ETL_V`             | - Is there data export for external backup?                     |
| **Disaster Recovery Testing** | ❌ No            | N/A                                   | - Is failover tested quarterly? - Are recovery times validated? |

---

## Notebook 4: Performance Efficiency

### Key Topic: MAXIMIZE (Get the most out of your queries and data)

| Sub-Topic                   | DDM Assessable? | DDM Views                       | Manual Assessment Questions                                                |
| --------------------------- | --------------- | ------------------------------- | -------------------------------------------------------------------------- |
| **Query Optimization**      | ⚠️ Partial      | Query history not in DDM        | - Are SELECT \* queries avoided? - Is Query Profile used for optimization? |
| **Clustering**              | ✅ Yes           | `TABLE_ETL_V` - clustering keys | None - fully automated                                                     |
| **Materialized Views**      | ✅ Yes           | `TABLE_ETL_V` - MV detection    | None - fully automated                                                     |
| **Result Caching**          | ❌ No            | N/A                             | - Are non-deterministic functions avoided?                                 |
| **Micro-partition Pruning** | ⚠️ Partial      | Query history not in DDM        | - Are queries filtering on clustered columns?                              |

### Key Topic: SCALE (Handle growing workloads efficiently)

| Sub-Topic                    | DDM Assessable? | DDM Views                               | Manual Assessment Questions |
| ---------------------------- | --------------- | --------------------------------------- | --------------------------- |
| **Warehouse Sizing**         | ✅ Yes           | `WAREHOUSE_ETL_V`                       | None - fully automated      |
| **Multi-Cluster Warehouses** | ✅ Yes           | `WAREHOUSE_ETL_V` - MCW config          | None - fully automated      |
| **Workload Isolation**       | ✅ Yes           | `WAREHOUSE_ETL_V` - multiple warehouses | None - fully automated      |
| **Scaling Policies**         | ✅ Yes           | `WAREHOUSE_ETL_V` - scaling policy      | None - fully automated      |

### Key Topic: IMPROVE (Continuously monitor and tune performance)

| Sub-Topic                   | DDM Assessable? | DDM Views                | Manual Assessment Questions                                                 |
| --------------------------- | --------------- | ------------------------ | --------------------------------------------------------------------------- |
| **Query Profiling**         | ❌ No            | N/A                      | - Is Query Profile used regularly? - Are spillage issues addressed?         |
| **QUERY\_HISTORY Analysis** | ❌ No            | Query history not in DDM | - Are performance trends monitored?                                         |
| **Warehouse Utilization**   | ⚠️ Partial      | Metering not in DDM      | - Is warehouse utilization tracked?                                         |
| **Iterative Tuning**        | ❌ No            | N/A                      | - Are performance baselines established? - Is A/B testing used for changes? |

### Key Topic: LEVERAGE (Use advanced Snowflake capabilities)

| Sub-Topic                       | DDM Assessable? | DDM Views                            | Manual Assessment Questions                     |
| ------------------------------- | --------------- | ------------------------------------ | ----------------------------------------------- |
| **Search Optimization Service** | ✅ Yes           | `TABLE_ETL_V` - SOS enabled          | None - fully automated                          |
| **Unistore**                    | ✅ Yes           | `TABLE_ETL_V` - Hybrid tables        | None - fully automated                          |
| **Snowpark**                    | ⚠️ Partial      | `FUNCTION_ETL_V` - Python UDFs/Procs | - Is Snowpark used for complex transformations? |
| **Dynamic Tables**              | ✅ Yes           | `TABLE_ETL_V` - Dynamic Tables       | None - fully automated                          |

---

## Notebook 5: Cost Optimization

### Key Topic: BUSINESS VALUE (Connect costs to outcomes)

| Sub-Topic                   | DDM Assessable? | DDM Views | Manual Assessment Questions                                                   |
| --------------------------- | --------------- | --------- | ----------------------------------------------------------------------------- |
| **ROI Analysis**            | ❌ No            | N/A       | - Is ROI tracked for key workloads? - Is value measured against cost?         |
| **Cost-Benefit Trade-offs** | ❌ No            | N/A       | - Are speed vs cost decisions documented? - Are trade-offs reviewed?          |
| **Value Attribution**       | ❌ No            | N/A       | - Is Snowflake spend tied to business outcomes?                               |
| **Stakeholder Alignment**   | ❌ No            | N/A       | - Do stakeholders understand their data costs? - Are SLA agreements in place? |

### Key Topic: VISIBILITY (Know where your spend is going)

| Sub-Topic               | DDM Assessable? | DDM Views                      | Manual Assessment Questions                                               |
| ----------------------- | --------------- | ------------------------------ | ------------------------------------------------------------------------- |
| **Cost Attribution**    | ✅ Yes           | `TAG_ETL_V` - cost center tags | None - fully automated                                                    |
| **Usage Dashboards**    | ❌ No            | N/A                            | - Are cost dashboards in place?                                           |
| **Chargeback/Showback** | ❌ No            | N/A                            | - Is there a chargeback process? - Are teams accountable for consumption? |
| **Anomaly Detection**   | ⚠️ Partial      | Metering not in DDM            | - Are cost spikes investigated?                                           |

### Key Topic: CONTROL (Prevent runaway costs)

| Sub-Topic               | DDM Assessable? | DDM Views                            | Manual Assessment Questions                                               |
| ----------------------- | --------------- | ------------------------------------ | ------------------------------------------------------------------------- |
| **Resource Monitors**   | ✅ Yes           | `RESOURCE_MONITOR_ETL_V`             | None - fully automated                                                    |
| **Warehouse Timeouts**  | ✅ Yes           | `WAREHOUSE_ETL_V` - AUTO\_SUSPEND    | None - fully automated                                                    |
| **Statement Timeouts**  | ⚠️ Partial      | `WAREHOUSE_ETL_V` - timeout settings | - Are statement timeouts configured per workload?                         |
| **Governance Policies** | ❌ No            | N/A                                  | - Is approval required for new warehouses? - Are size increases reviewed? |

### Key Topic: OPTIMIZATION (Reduce costs without sacrificing value)

| Sub-Topic                | DDM Assessable? | DDM Views                                                      | Manual Assessment Questions                           |
| ------------------------ | --------------- | -------------------------------------------------------------- | ----------------------------------------------------- |
| **Right-Sizing**         | ⚠️ Partial      | `WAREHOUSE_ETL_V`                                              | - Are warehouses regularly reviewed for right-sizing? |
| **Auto-Suspend Tuning**  | ✅ Yes           | `WAREHOUSE_ETL_V` - AUTO\_SUSPEND                              | None - fully automated                                |
| **Storage Optimization** | ⚠️ Partial      | `TABLE_ETL_V` - transient tables, `DATABASE_ETL_V` - retention | - Are staging tables transient?                       |
| **Query Efficiency**     | ❌ No            | Query history not in DDM                                       | - Are expensive queries optimized?                    |
| **Serverless Features**  | ✅ Yes           | `USER_TASK_ETL_V`, `PIPE_ETL_V`, `TABLE_ETL_V`                 | None - fully automated                                |

---

## Implementation Approach for Each Notebook

### Step 1: Update Header Structure

- Replace "Principle X" headers with "Key Topic: \[NAME]" headers
- Add Sub-Topic sections under each Key Topic

### Step 2: Reorganize Existing Cells

- Map existing DDM queries to appropriate Key Topics/Sub-Topics
- Some queries may serve multiple sub-topics

### Step 3: Add Manual Assessment Sections

For sub-topics without DDM data, add markdown cells with:

```
### Manual Assessment: [Sub-Topic Name]
**Questions to Ask:**
1. [Question 1]
2. [Question 2]

**Evidence to Request:**
- [Document/artifact to review]

**Scoring Guidance:**
- Score 5: [criteria]
- Score 3: [criteria]
- Score 1: [criteria]
```

### Step 4: Update Scoring

- Change from per-principle scoring to per-topic scoring
- Update the summary cell to aggregate by Key Topic

### Step 5: Update Cortex Assessment Prompt

- Modify the LLM prompt to use Key Topics instead of Principles
- Include manual assessment responses in the context

---

## Summary: DDM Coverage by Notebook

| Notebook                  | Fully DDM    | Partial DDM  | Manual Only  |
| ------------------------- | ------------ | ------------ | ------------ |
| 01-Operational Excellence | 5 sub-topics | 6 sub-topics | 5 sub-topics |
| 02-Security               | 6 sub-topics | 4 sub-topics | 6 sub-topics |
| 03-Reliability            | 5 sub-topics | 5 sub-topics | 6 sub-topics |
| 04-Performance            | 9 sub-topics | 4 sub-topics | 4 sub-topics |
| 05-Cost Optimization      | 5 sub-topics | 5 sub-topics | 8 sub-topics |

---

## Estimated Effort

- **Per Notebook**: 2-3 hours
- **Total**: 10-15 hours
- **Recommended Order**: 01 → 02 → 03 → 04 → 05 (increasing complexity awareness)
