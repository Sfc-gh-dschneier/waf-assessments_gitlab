# Well-Architected Framework: Operational Excellence

## LLM Assessment Instructions

When assessing a Snowflake account for Operational Excellence, follow this structured approach:

### Assessment Methodology
1. **Query the account** using the SQL queries provided in the "Assessment Queries" section
2. **Evaluate each topic** against the criteria in the scoring rubric
3. **Generate findings** in a consistent format: Finding, Impact, Recommendation
4. **Calculate scores** using the scoring rubric (1-5 scale per topic)
5. **Prioritize recommendations** by impact and effort

### Output Format
For each assessment, provide:
- **Executive Summary**: Overall score (1-5) with 2-3 sentence summary
- **Topic Scores**: Individual scores for each of the 4 key topics
- **Critical Findings**: Top 3-5 issues requiring immediate attention
- **Recommendations**: Actionable items sorted by priority (High/Medium/Low)
- **Quick Wins**: Changes that can be implemented within 1 week

### Scoring Guidelines
- **5 (Excellent)**: Best practices fully implemented, automated, monitored
- **4 (Good)**: Most best practices implemented, minor gaps
- **3 (Moderate)**: Basic implementation, significant improvement opportunities
- **2 (Limited)**: Minimal implementation, major gaps
- **1 (Poor)**: Not implemented or fundamentally flawed

---

## Overview

Operational Excellence focuses on preparing, implementing, and automating operations for continuous improvement. In Snowflake, this pillar emphasizes setting the foundation for success, deploying with consistency, enabling team effectiveness, and reducing manual toil.

---

## Key Topics

### Prepare

Set the foundation for operational success.

#### Data Modeling

Design schemas that balance normalization with query performance; consider Data Vault or dimensional modeling based on use case.

| Approach | Description | Use Case |
|----------|-------------|----------|
| **Dimensional Modeling** | Star/snowflake schema design | BI and analytics workloads |
| **Data Vault** | Hub, link, and satellite pattern | Auditable, historical data |
| **Normalized** | 3NF design | OLTP-style transactional data |
| **Wide Tables** | Denormalized for performance | High-performance analytics |

#### Naming Conventions

Establish consistent naming standards for databases, schemas, tables, warehouses, and roles.

| Object Type | Convention Example | Notes |
|-------------|-------------------|-------|
| Databases | `PROD_ANALYTICS`, `DEV_RAW` | Environment prefix |
| Schemas | `RAW`, `CURATED`, `REPORTING` | Layer-based naming |
| Tables | `FACT_SALES`, `DIM_CUSTOMER` | Type prefix |
| Warehouses | `ETL_WH`, `BI_WH`, `DS_WH` | Workload-based |
| Roles | `DATA_ENGINEER`, `ANALYST_RO` | Function-based |

#### Environment Strategy

Define DEV/TEST/PROD environment separation and promotion processes.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Zero-Copy Cloning** | Instant copies without data duplication | DEV/TEST environments |
| **Database Cloning** | Full database copy | Environment refresh |
| **Schema Cloning** | Schema-level copy | Isolated testing |
| **Time Travel** | Point-in-time access | Rollback capability |

#### Capacity Planning

Estimate storage and compute needs based on data volumes and query patterns.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Account Usage Views** | Historical consumption data | Trend analysis |
| **Resource Monitors** | Credit tracking and alerts | Budget planning |
| **Storage Metrics** | Data volume tracking | Growth forecasting |
| **Query History** | Workload patterns | Compute planning |

**Assessment Criteria:**
- Is there a documented data modeling approach?
- Are naming conventions defined and enforced?
- Is environment separation properly implemented?
- Is capacity planning data being tracked?

---

### Implement

Deploy with consistency and repeatability.

#### Infrastructure as Code

Use Terraform or Snowflake CLI to manage Snowflake objects declaratively.

| Tool | Description | Use Case |
|------|-------------|----------|
| **Snowflake Terraform Provider** | IaC for Snowflake resources | Declarative resource management |
| **Snowflake CLI (snow)** | Command-line management | Scripted deployments, CI/CD |
| **Schemachange** | Database migration tool | Version-controlled schema changes |
| **Flyway** | Database migration tool | Java-based migrations |

#### CI/CD Pipelines

Implement automated deployment pipelines using tools like GitHub Actions, Azure DevOps, or dbt Cloud.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Git Integration** | Native Git repository connections | Version control for scripts |
| **GitHub Actions** | Automated workflows | CI/CD pipelines |
| **Azure DevOps** | Microsoft CI/CD platform | Enterprise deployments |
| **dbt Cloud** | Managed dbt platform | Analytics engineering CI/CD |

#### Version Control

Store all DDL, stored procedures, and configuration in Git repositories.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Git Stages** | Native Git repository integration | Code versioning |
| **Snowflake Notebooks** | Collaborative development | Documented workflows |
| **Stored Procedures** | Encapsulated logic | Versioned business logic |
| **UDFs** | Reusable functions | Versioned transformations |

#### Schema Migration

Use tools like Schemachange for controlled schema evolution.

| Approach | Description | Use Case |
|----------|-------------|----------|
| **Migration Scripts** | Numbered DDL files | Sequential changes |
| **Idempotent DDL** | CREATE OR REPLACE | Repeatable deployments |
| **Change Tracking** | Migration history table | Audit trail |
| **Rollback Scripts** | Reverse migrations | Recovery capability |

**Assessment Criteria:**
- Are infrastructure changes managed via Terraform/CLI?
- Is Git integration configured for code version control?
- Are schema changes tracked and versioned?
- Are deployment pipelines automated (CI/CD)?

---

### Collaborate

Enable team effectiveness.

#### Documentation

Maintain data dictionaries, lineage documentation, and runbooks.

| Artifact | Description | Use Case |
|----------|-------------|----------|
| **Data Dictionary** | Column descriptions and metadata | Data understanding |
| **Lineage Documentation** | Data flow documentation | Impact analysis |
| **Runbooks** | Operational procedures | Incident response |
| **Architecture Diagrams** | System documentation | Onboarding |

#### Standards

Publish and enforce coding standards, review processes, and approval workflows.

| Standard Type | Description | Use Case |
|---------------|-------------|----------|
| **SQL Style Guide** | Formatting and naming rules | Code consistency |
| **Review Process** | PR/MR requirements | Quality assurance |
| **Approval Workflows** | Change management | Production safety |
| **Testing Standards** | Test requirements | Quality gates |

#### Cross-Team Communication

Establish clear ownership and communication channels between data engineering, analytics, and platform teams.

| Practice | Description | Use Case |
|----------|-------------|----------|
| **Object Tagging** | Ownership metadata | Accountability |
| **Data Sharing** | Cross-team data access | Collaboration |
| **Comments** | Object descriptions | Documentation |
| **Alerts** | Team notifications | Communication |

**Assessment Criteria:**
- Is documentation maintained and current?
- Are coding standards defined and enforced?
- Is there clear ownership of data assets?
- Are communication channels established?

---

### Automate

Reduce manual toil and human error.

#### Task Scheduling

Use Snowflake Tasks and Streams for event-driven and scheduled data pipelines.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Tasks** | Scheduled SQL/procedure execution | Automated workflows |
| **Streams** | Change data capture | Incremental processing |
| **Dynamic Tables** | Declarative transformations | Self-managing pipelines |
| **Serverless Tasks** | Managed compute for tasks | Zero infrastructure |

#### Alerting

Configure alerts for task failures, data quality issues, and SLA breaches.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Alerts** | Condition-based notifications | Proactive monitoring |
| **Resource Monitors** | Usage tracking and alerts | Budget control |
| **Email Notifications** | Alert delivery | Team notification |
| **Webhook Integration** | External system alerts | Tool integration |

#### Self-Healing

Implement retry logic and automated remediation for common failure scenarios.

| Pattern | Description | Use Case |
|---------|-------------|----------|
| **Task Retry** | Automatic retry on failure | Transient error handling |
| **Error Handling** | TRY/CATCH in procedures | Graceful degradation |
| **ALLOW_OVERLAPPING_EXECUTION** | Prevent duplicate runs | Idempotent execution |
| **USER_TASK_TIMEOUT_MS** | Timeout configuration | Runaway prevention |

**Assessment Criteria:**
- Are Tasks/Streams used for automation?
- Are Alerts configured for critical events?
- Is there retry logic for failure scenarios?
- Are operational procedures automated?

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    PREPARE LAYER                                 │
│   Data Modeling │ Naming Conventions │ Environment Strategy     │
├─────────────────────────────────────────────────────────────────┤
│                  IMPLEMENT LAYER                                 │
│     Terraform │ CLI │ Git Integration │ CI/CD Pipelines         │
├─────────────────────────────────────────────────────────────────┤
│                  COLLABORATE LAYER                               │
│   Documentation │ Standards │ Ownership │ Communication         │
├─────────────────────────────────────────────────────────────────┤
│                   AUTOMATE LAYER                                 │
│   Tasks │ Streams │ Dynamic Tables │ Alerts │ Self-Healing      │
└─────────────────────────────────────────────────────────────────┘
```

---

## Implementation Patterns

### Automated Deployment Pipeline

```sql
CREATE OR REPLACE TASK data_refresh_task
  WAREHOUSE = compute_wh
  SCHEDULE = 'USING CRON 0 6 * * * America/New_York'
AS
  CALL refresh_data_pipeline();

ALTER TASK data_refresh_task RESUME;
```

### Change Management with Cloning

```sql
CREATE DATABASE dev_analytics CLONE prod_analytics;

-- Test changes safely
-- If successful, apply to production
-- If failed, drop clone with no impact
DROP DATABASE dev_analytics;
```

### Operational Monitoring Setup

```sql
CREATE OR REPLACE ALERT task_failure_alert
  WAREHOUSE = monitor_wh
  SCHEDULE = '5 MINUTE'
IF (EXISTS (
  SELECT * FROM TABLE(information_schema.task_history())
  WHERE state = 'FAILED'
    AND scheduled_time > DATEADD(minute, -10, CURRENT_TIMESTAMP())
))
THEN
  CALL notify_operations_team('Task failure detected');

ALTER ALERT task_failure_alert RESUME;
```

### Resource Monitor Configuration

```sql
CREATE OR REPLACE RESOURCE MONITOR account_monitor
  WITH CREDIT_QUOTA = 10000
  FREQUENCY = MONTHLY
  START_TIMESTAMP = IMMEDIATELY
  TRIGGERS
    ON 75 PERCENT DO NOTIFY
    ON 90 PERCENT DO NOTIFY
    ON 100 PERCENT DO SUSPEND;

ALTER ACCOUNT SET RESOURCE_MONITOR = account_monitor;
```

---

## Assessment Queries

Use these queries to assess the Operational Excellence posture of an account:

### IaC Tool Detection

```sql
SELECT 
  CASE 
    WHEN CLIENT_APPLICATION_ID ILIKE '%terraform%' THEN 'Terraform'
    WHEN CLIENT_APPLICATION_ID ILIKE '%snowflake-cli%' OR CLIENT_APPLICATION_ID ILIKE '%snowcli%' THEN 'Snowflake CLI'
    WHEN CLIENT_APPLICATION_ID ILIKE '%dbt%' THEN 'dbt'
    WHEN CLIENT_APPLICATION_ID ILIKE '%schemachange%' THEN 'Schemachange'
    ELSE 'Other'
  END as iac_tool,
  COUNT(*) as query_count,
  COUNT(DISTINCT USER_NAME) as user_count
FROM snowflake.account_usage.query_history qh
LEFT JOIN snowflake.account_usage.sessions s ON qh.SESSION_ID = s.SESSION_ID
WHERE qh.START_TIME > DATEADD(day, -30, CURRENT_TIMESTAMP())
  AND (
    CLIENT_APPLICATION_ID ILIKE '%terraform%'
    OR CLIENT_APPLICATION_ID ILIKE '%snowflake-cli%'
    OR CLIENT_APPLICATION_ID ILIKE '%snowcli%'
    OR CLIENT_APPLICATION_ID ILIKE '%dbt%'
    OR CLIENT_APPLICATION_ID ILIKE '%schemachange%'
  )
GROUP BY 1
ORDER BY query_count DESC;
```

### Git Integration Check

```sql
SELECT 
  stage_name,
  stage_type,
  stage_url,
  created
FROM snowflake.account_usage.stages
WHERE stage_type = 'Git Repository'
ORDER BY created DESC;
```

### Resource Monitor Status

```sql
SHOW RESOURCE MONITORS;

SELECT 
  name,
  credit_quota,
  used_credits,
  remaining_credits,
  ROUND(used_credits / NULLIF(credit_quota, 0) * 100, 2) as pct_used
FROM snowflake.account_usage.resource_monitors
WHERE end_time > CURRENT_TIMESTAMP();
```

### Alert Configuration Check

```sql
SELECT 
  name,
  state,
  schedule,
  condition,
  action
FROM snowflake.account_usage.alerts
ORDER BY created DESC;
```

### Task Health Check

```sql
SELECT 
  name,
  state,
  COUNT(*) as execution_count,
  SUM(CASE WHEN state = 'SUCCEEDED' THEN 1 ELSE 0 END) as success_count,
  SUM(CASE WHEN state = 'FAILED' THEN 1 ELSE 0 END) as failure_count,
  ROUND(SUM(CASE WHEN state = 'SUCCEEDED' THEN 1 ELSE 0 END) / 
        NULLIF(COUNT(*), 0) * 100, 2) as success_rate
FROM TABLE(information_schema.task_history(
  scheduled_time_range_start => DATEADD(day, -7, CURRENT_TIMESTAMP())
))
GROUP BY name, state
ORDER BY failure_count DESC;
```

### Time Travel Configuration

```sql
SELECT 
  database_name,
  retention_time,
  CASE 
    WHEN retention_time = 0 THEN 'No Time Travel'
    WHEN retention_time BETWEEN 1 AND 7 THEN 'Standard'
    WHEN retention_time > 7 THEN 'Extended (Enterprise+)'
  END as retention_category
FROM snowflake.account_usage.databases
WHERE deleted IS NULL
ORDER BY retention_time DESC;
```

### Warehouse Monitoring

```sql
SELECT 
  warehouse_name,
  AVG(avg_running) as avg_queries_running,
  AVG(avg_queued_load) as avg_queue_load,
  AVG(avg_blocked) as avg_blocked
FROM snowflake.account_usage.warehouse_load_history
WHERE start_time > DATEADD(day, -7, CURRENT_TIMESTAMP())
GROUP BY warehouse_name
ORDER BY avg_queue_load DESC;
```

### Replication Status

```sql
SELECT 
  database_name,
  is_primary,
  primary_database_name,
  replication_group_name
FROM snowflake.account_usage.database_replication_usage_history
WHERE start_time > DATEADD(day, -30, CURRENT_TIMESTAMP())
GROUP BY 1, 2, 3, 4;
```

---

## Scoring Rubric

### Prepare
| Score | Criteria |
|-------|----------|
| 5 | Data modeling documented, naming conventions enforced, environments separated, capacity tracked |
| 4 | Most preparation practices in place, minor gaps |
| 3 | Basic preparation, some documentation |
| 2 | Limited preparation, ad-hoc approach |
| 1 | No preparation, no standards |

### Implement
| Score | Criteria |
|-------|----------|
| 5 | Terraform/CLI for all resources, Git integration active, CI/CD pipelines, no manual DDL |
| 4 | IaC for most resources, Git integration, some manual changes |
| 3 | IaC for some resources, limited version control |
| 2 | Minimal IaC adoption, mostly manual changes |
| 1 | No IaC, all manual operations |

### Collaborate
| Score | Criteria |
|-------|----------|
| 5 | Full documentation, standards enforced, clear ownership, active communication |
| 4 | Good documentation and standards, some gaps |
| 3 | Basic documentation, informal standards |
| 2 | Limited documentation, no standards |
| 1 | No documentation, no collaboration practices |

### Automate
| Score | Criteria |
|-------|----------|
| 5 | Tasks/Streams for all pipelines, alerts configured, self-healing patterns |
| 4 | Most pipelines automated, some alerting |
| 3 | Mix of manual and automated processes |
| 2 | Mostly manual operations |
| 1 | No automation |

---

## Core Principles

- Treat infrastructure as code
- Establish and enforce naming/tagging conventions
- Implement robust change management
- Automate repetitive operational tasks

---

## Best Practices Checklist

- [ ] Document data modeling approach and standards
- [ ] Implement naming conventions for all objects
- [ ] Separate DEV/TEST/PROD environments using cloning
- [ ] Implement Infrastructure as Code using Terraform or Snowflake CLI
- [ ] Use Git integration for version control of all database objects
- [ ] Configure Resource Monitors with appropriate thresholds (75%, 90%, 100%)
- [ ] Set up Alerts for critical operational events (task failures, quota warnings)
- [ ] Establish Time Travel retention policies appropriate for workloads
- [ ] Document and automate runbooks using stored procedures
- [ ] Review Query History weekly for optimization opportunities
- [ ] Test disaster recovery procedures quarterly
- [ ] Use zero-copy cloning for all development and testing
- [ ] Implement Streams and Tasks for incremental processing
- [ ] Configure statement timeouts to prevent runaway queries
- [ ] Set up multi-cluster warehouses for production workloads
- [ ] Implement CI/CD pipelines for database changes

---

## Related Documentation

- [Snowflake CLI Documentation](https://docs.snowflake.com/en/developer-guide/snowflake-cli)
- [Terraform Provider](https://docs.snowflake.com/en/developer-guide/terraform)
- [Time Travel](https://docs.snowflake.com/en/user-guide/data-time-travel)
- [Tasks and Streams](https://docs.snowflake.com/en/user-guide/tasks-intro)
- [Resource Monitors](https://docs.snowflake.com/en/user-guide/resource-monitors)
- [Alerts](https://docs.snowflake.com/en/user-guide/alerts)
- [Replication and Failover](https://docs.snowflake.com/en/user-guide/replication-intro)
