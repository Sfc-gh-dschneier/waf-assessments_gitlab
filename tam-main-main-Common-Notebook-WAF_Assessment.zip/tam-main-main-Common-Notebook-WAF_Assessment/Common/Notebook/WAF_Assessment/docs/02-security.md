# Well-Architected Framework: Security & Governance

## LLM Assessment Instructions

When assessing a Snowflake account for Security & Governance, follow this structured approach:

### Assessment Methodology
1. **Query the account** using the SQL queries provided in the "Assessment Queries" section
2. **Evaluate each topic** against the criteria in the scoring rubric
3. **Generate findings** in a consistent format: Finding, Impact, Recommendation
4. **Calculate scores** using the scoring rubric (1-5 scale per topic)
5. **Prioritize recommendations** by risk level and compliance impact

### Output Format
For each assessment, provide:
- **Executive Summary**: Overall score (1-5) with 2-3 sentence summary
- **Topic Scores**: Individual scores for each of the 4 key topics
- **Critical Findings**: Top 3-5 security risks requiring immediate attention
- **Recommendations**: Actionable items sorted by priority (Critical/High/Medium/Low)
- **Quick Wins**: Security improvements that can be implemented within 1 week

### Scoring Guidelines
- **5 (Excellent)**: Security best practices fully implemented, defense-in-depth, comprehensive audit
- **4 (Good)**: Most security controls implemented, minor gaps
- **3 (Moderate)**: Basic security controls, significant improvement opportunities
- **2 (Limited)**: Minimal security controls, major vulnerabilities
- **1 (Poor)**: Critical security gaps, immediate action required

### Risk Classification
- **Critical**: Data breach risk, compliance violation, immediate remediation required
- **High**: Significant security gap, remediation within 30 days
- **Medium**: Security improvement opportunity, remediation within 90 days
- **Low**: Best practice enhancement, plan for future implementation

---

## Overview

The Security & Governance pillar enables secure, governed, and compliant data platforms. Snowflake provides comprehensive security capabilities built into the platform at every layer, focusing on protecting access, controlling data visibility, meeting compliance requirements, and detecting security events.

---

## Key Topics

### Secure

Protect access to your Snowflake environment.

#### Authentication

Enforce MFA, integrate with SSO/SAML providers, use key-pair authentication for service accounts.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **SSO/SAML Integration** | Federated authentication | Enterprise identity provider integration |
| **MFA (Multi-Factor Authentication)** | Additional authentication factor | Enhanced user security |
| **Key Pair Authentication** | RSA key-based auth | Service accounts, automation |
| **OAuth** | Token-based authentication | Application and API authentication |
| **SCIM** | Automated user provisioning | Identity lifecycle management |

#### Network Security

Configure network policies to restrict IP ranges, use AWS PrivateLink / Azure Private Link / GCP Private Service Connect for private connectivity.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Network Policies** | IP allowlisting/blocklisting | Network-level access control |
| **AWS PrivateLink** | Private connectivity to AWS | Network isolation |
| **Azure Private Link** | Private connectivity to Azure | Network isolation |
| **GCP Private Service Connect** | Private connectivity to GCP | Network isolation |

#### Encryption

Leverage Snowflake's automatic encryption at rest and in transit; consider Tri-Secret Secure for customer-managed keys.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **AES-256 Encryption** | Encryption at rest | Data protection by default |
| **TLS 1.2+** | Encrypted connections | Secure data transmission |
| **Tri-Secret Secure** | Customer-managed keys | Enhanced encryption control |
| **External Tokenization** | Token-based data protection | Sensitive data handling |

**Assessment Criteria:**
- Is SSO/SAML configured for user authentication?
- Is MFA enforced for all human users?
- Are service accounts using key pair authentication?
- Are Network Policies restricting access?
- Is Private Connectivity configured for production?

---

### Govern

Control who can access what data.

#### Access Control

Implement role-based access control (RBAC) with functional roles and access roles hierarchy.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Role-Based Access Control (RBAC)** | Granular permissions | Least-privilege access |
| **Database Roles** | Object-level role management | Fine-grained database permissions |
| **Functional Roles** | Job function-based roles | User assignment |
| **Access Roles** | Permission-based roles | Object access grants |

#### Data Classification

Use object tagging to classify sensitive data (PII, PHI, financial).

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Object Tagging** | Metadata classification | Data governance |
| **Tag-Based Masking** | Policy linked to tags | Automated data protection |
| **System Tags** | Snowflake-managed classification | Compliance automation |
| **Custom Tags** | User-defined classification | Business categorization |

#### Data Protection

Apply dynamic data masking policies and row access policies to restrict data visibility based on user context.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Dynamic Data Masking** | Context-aware data obfuscation | Role-based data visibility |
| **Row Access Policies** | Row-level security | Multi-tenant data isolation |
| **Column-Level Security** | Column masking and access | PII protection |
| **Projection Policies** | Column access control | Sensitive column restriction |

**Assessment Criteria:**
- Is RBAC implemented with role hierarchy?
- Are Row Access Policies used for multi-tenant isolation?
- Is Dynamic Data Masking applied to sensitive columns?
- Are data classification tags applied?
- Is least-privilege principle followed?

---

### Comply

Meet regulatory and audit requirements.

#### Audit Logging

Enable and monitor ACCESS_HISTORY, LOGIN_HISTORY, and QUERY_HISTORY for compliance reporting.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **ACCESS_HISTORY** | Data access audit trail | Who accessed what data |
| **LOGIN_HISTORY** | Authentication logging | User activity tracking |
| **QUERY_HISTORY** | Query execution logs | Forensic analysis |
| **SESSION_HISTORY** | Session-level logging | Connection auditing |

#### Data Residency

Use region-specific deployments and cross-region replication policies to meet data sovereignty requirements.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Regional Deployment** | Region-specific accounts | Data sovereignty |
| **Replication Policies** | Cross-region data sync | Compliance with residency |
| **Data Sharing Restrictions** | Control data distribution | Regulatory compliance |
| **Organization Policies** | Account-level controls | Enterprise governance |

#### Trust Center

Leverage Snowflake Trust Center for compliance certifications and security posture visibility.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Trust Center** | Security posture dashboard | Compliance monitoring |
| **Compliance Certifications** | SOC 2, HIPAA, etc. | Regulatory attestation |
| **Security Assessments** | Automated checks | Proactive compliance |
| **Recommendations** | Best practice guidance | Continuous improvement |

**Assessment Criteria:**
- Is Access History being monitored?
- Are audit logs retained per compliance requirements?
- Is Trust Center being reviewed regularly?
- Are data residency requirements met?

---

### Monitor

Detect and respond to security events.

#### Security Dashboards

Build dashboards using ACCOUNT_USAGE views to track access patterns and anomalies.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Account Usage Views** | Comprehensive security data | Dashboard building |
| **Streamlit Apps** | Interactive dashboards | Security visualization |
| **Scheduled Reports** | Automated reporting | Regular monitoring |
| **Custom Metrics** | Business-specific KPIs | Tailored monitoring |

#### Alerting

Configure alerts for failed logins, privilege escalations, and unusual data access patterns.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Alerts** | Condition-based notifications | Proactive detection |
| **Email Notifications** | Alert delivery | Team notification |
| **Webhook Integration** | External system alerts | SIEM integration |
| **Scheduled Checks** | Regular security scans | Continuous monitoring |

#### SIEM Integration

Export security events to external security tools for centralized monitoring.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Security Integrations** | External tool connections | SIEM integration |
| **Event Sharing** | Security event export | Centralized monitoring |
| **API Access** | Programmatic data access | Automation |
| **Log Export** | Audit log export | Long-term retention |

**Assessment Criteria:**
- Are security dashboards in place?
- Are alerts configured for security events?
- Is there SIEM integration?
- Are failed logins being tracked and alerted?

---

## Security Architecture Layers

```
┌─────────────────────────────────────────────────────────────────┐
│                    SECURE LAYER                                  │
│  SSO/SAML │ MFA │ Key Pair Auth │ Network Policies │ Encryption │
├─────────────────────────────────────────────────────────────────┤
│                   GOVERN LAYER                                   │
│  RBAC │ Database Roles │ Row Access Policies │ Data Masking     │
├─────────────────────────────────────────────────────────────────┤
│                   COMPLY LAYER                                   │
│  Access History │ Login History │ Trust Center │ Data Residency │
├─────────────────────────────────────────────────────────────────┤
│                   MONITOR LAYER                                  │
│  Security Dashboards │ Alerts │ SIEM Integration │ Audit Logs   │
└─────────────────────────────────────────────────────────────────┘
```

---

## Implementation Patterns

### Role Hierarchy Design

```sql
CREATE ROLE data_engineer;
CREATE ROLE data_analyst;
CREATE ROLE data_scientist;

CREATE ROLE raw_data_reader;
CREATE ROLE curated_data_reader;
CREATE ROLE sensitive_data_reader;

GRANT ROLE raw_data_reader TO ROLE data_engineer;
GRANT ROLE curated_data_reader TO ROLE data_analyst;
GRANT ROLE curated_data_reader TO ROLE data_scientist;

GRANT USAGE ON DATABASE analytics TO ROLE curated_data_reader;
GRANT SELECT ON ALL TABLES IN SCHEMA analytics.curated TO ROLE curated_data_reader;
```

### Dynamic Data Masking

```sql
CREATE OR REPLACE MASKING POLICY pii_mask AS (val STRING) 
RETURNS STRING ->
  CASE
    WHEN CURRENT_ROLE() IN ('PII_ADMIN', 'COMPLIANCE') THEN val
    ELSE '***MASKED***'
  END;

ALTER TABLE customers MODIFY COLUMN email 
  SET MASKING POLICY pii_mask;
```

### Row Access Policy

```sql
CREATE OR REPLACE ROW ACCESS POLICY tenant_isolation AS (tenant_id VARCHAR)
RETURNS BOOLEAN ->
  tenant_id = CURRENT_SESSION_CONTEXT('tenant_id')
  OR CURRENT_ROLE() = 'ADMIN';

ALTER TABLE orders ADD ROW ACCESS POLICY tenant_isolation ON (tenant_id);
```

### Network Policy

```sql
CREATE OR REPLACE NETWORK POLICY corporate_access
  ALLOWED_IP_LIST = ('192.168.1.0/24', '10.0.0.0/8')
  BLOCKED_IP_LIST = ('192.168.1.99');

ALTER ACCOUNT SET NETWORK_POLICY = corporate_access;
```

### Session and Authentication Policies

```sql
CREATE OR REPLACE SESSION POLICY secure_session
  SESSION_IDLE_TIMEOUT_MINS = 30
  SESSION_UI_IDLE_TIMEOUT_MINS = 15;

CREATE OR REPLACE AUTHENTICATION POLICY require_mfa
  MFA_AUTHENTICATION_METHODS = ('TOTP')
  CLIENT_TYPES = ('SNOWFLAKE_UI');

ALTER USER analyst_user SET SESSION_POLICY = secure_session;
ALTER USER analyst_user SET AUTHENTICATION_POLICY = require_mfa;
```

---

## Assessment Queries

Use these queries to assess the Security & Governance posture of an account:

### SSO/SAML Configuration Check

```sql
SHOW SECURITY INTEGRATIONS;

SELECT 
  name,
  login_name,
  has_password,
  ext_authn_duo,
  ext_authn_uid
FROM snowflake.account_usage.users
WHERE deleted_on IS NULL
  AND has_password = FALSE;
```

### MFA Adoption

```sql
SELECT 
  name,
  login_name,
  ext_authn_duo,
  CASE 
    WHEN ext_authn_duo = TRUE THEN 'MFA Enabled'
    ELSE 'MFA Not Enabled'
  END as mfa_status
FROM snowflake.account_usage.users
WHERE deleted_on IS NULL
  AND name NOT IN ('SNOWFLAKE')
ORDER BY mfa_status, name;
```

### Failed Login Attempts

```sql
SELECT 
  user_name,
  client_ip,
  error_code,
  error_message,
  COUNT(*) as failed_attempts
FROM snowflake.account_usage.login_history
WHERE is_success = 'NO'
  AND event_timestamp > DATEADD(hour, -24, CURRENT_TIMESTAMP())
GROUP BY user_name, client_ip, error_code, error_message
HAVING COUNT(*) > 5
ORDER BY failed_attempts DESC;
```

### Network Policy Status

```sql
SHOW NETWORK POLICIES;

SELECT 
  name,
  network_policy
FROM snowflake.account_usage.users
WHERE deleted_on IS NULL
  AND network_policy IS NOT NULL;
```

### RBAC Analysis

```sql
SELECT 
  grantee_name as role_name,
  role as granted_role,
  granted_by,
  created_on
FROM snowflake.account_usage.grants_to_roles
WHERE granted_on = 'ROLE'
  AND deleted_on IS NULL
ORDER BY grantee_name, role;

SELECT 
  grantee_name as user_name,
  role,
  granted_by,
  created_on
FROM snowflake.account_usage.grants_to_users
WHERE role = 'ACCOUNTADMIN'
  AND deleted_on IS NULL;
```

### Masking Policy Coverage

```sql
SELECT 
  policy_db,
  policy_schema,
  policy_name,
  ref_database_name,
  ref_schema_name,
  ref_entity_name,
  ref_column_name
FROM snowflake.account_usage.policy_references
WHERE policy_kind = 'MASKING_POLICY'
  AND deleted IS NULL;

SELECT 
  table_catalog,
  table_schema,
  table_name,
  column_name
FROM snowflake.account_usage.columns
WHERE (
  LOWER(column_name) LIKE '%email%'
  OR LOWER(column_name) LIKE '%ssn%'
  OR LOWER(column_name) LIKE '%phone%'
  OR LOWER(column_name) LIKE '%credit%card%'
)
  AND deleted IS NULL
ORDER BY table_catalog, table_schema, table_name;
```

### Row Access Policy Check

```sql
SELECT 
  policy_db,
  policy_schema,
  policy_name,
  ref_database_name,
  ref_schema_name,
  ref_entity_name
FROM snowflake.account_usage.policy_references
WHERE policy_kind = 'ROW_ACCESS_POLICY'
  AND deleted IS NULL;
```

### Session Policy Check

```sql
SHOW SESSION POLICIES;

SELECT 
  name,
  session_policy
FROM snowflake.account_usage.users
WHERE deleted_on IS NULL
  AND session_policy IS NOT NULL;
```

---

## Scoring Rubric

### Secure
| Score | Criteria |
|-------|----------|
| 5 | SSO for all users, MFA enforced, key pair for service accounts, private connectivity, network policies |
| 4 | SSO configured, MFA for most users, key pair auth used, some network controls |
| 3 | SSO for some users, MFA optional, password-based service accounts |
| 2 | Limited SSO, no MFA enforcement |
| 1 | Password-only authentication, no MFA, no network controls |

### Govern
| Score | Criteria |
|-------|----------|
| 5 | RBAC hierarchy, masking on all PII, row access policies, data classification tags |
| 4 | Good RBAC, masking on most PII, some row policies |
| 3 | Basic RBAC, partial masking coverage |
| 2 | Minimal RBAC, no masking policies |
| 1 | No role hierarchy, direct object grants, no data protection |

### Comply
| Score | Criteria |
|-------|----------|
| 5 | Access History monitored, Trust Center reviewed, audit retention policy, data residency met |
| 4 | Most compliance controls in place, regular reviews |
| 3 | Basic audit awareness, ad-hoc review |
| 2 | Minimal audit review |
| 1 | No audit monitoring, no compliance controls |

### Monitor
| Score | Criteria |
|-------|----------|
| 5 | Security dashboards active, alerts for all events, SIEM integration, continuous monitoring |
| 4 | Good monitoring, some alerting |
| 3 | Basic monitoring, reactive approach |
| 2 | Limited monitoring |
| 1 | No security monitoring |

---

## Core Principles

- Apply zero-trust and least-privilege access
- Classify and tag sensitive data
- Automate compliance checks and audits
- Monitor for security anomalies continuously

---

## Best Practices Checklist

- [ ] Implement SSO with your identity provider
- [ ] Enforce MFA for all human users
- [ ] Use key pair authentication for service accounts
- [ ] Design role hierarchy following least-privilege principle
- [ ] Implement Row Access Policies for multi-tenant scenarios
- [ ] Apply Dynamic Data Masking to all PII columns
- [ ] Configure Network Policies to restrict access
- [ ] Enable Private Connectivity for production workloads
- [ ] Review Access History weekly for anomalies
- [ ] Set up Alerts for security-relevant events (failed logins, privilege grants)
- [ ] Classify data using Object Tagging
- [ ] Implement session and authentication policies
- [ ] Consider Tri-Secret Secure for highly sensitive data
- [ ] Regular security posture review using Trust Center
- [ ] Integrate with SIEM for centralized monitoring
- [ ] Document and test incident response procedures

---

## Related Documentation

- [Security Overview](https://docs.snowflake.com/en/user-guide/security)
- [Access Control](https://docs.snowflake.com/en/user-guide/security-access-control)
- [Data Masking](https://docs.snowflake.com/en/user-guide/security-column-ddm)
- [Row Access Policies](https://docs.snowflake.com/en/user-guide/security-row)
- [Network Policies](https://docs.snowflake.com/en/user-guide/network-policies)
- [Private Connectivity](https://docs.snowflake.com/en/user-guide/private-connectivity)
- [Trust Center](https://docs.snowflake.com/en/user-guide/trust-center)
