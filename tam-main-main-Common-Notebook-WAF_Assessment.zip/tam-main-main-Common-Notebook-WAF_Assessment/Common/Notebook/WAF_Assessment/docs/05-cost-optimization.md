# Well-Architected Framework: Cost Optimization

## LLM Assessment Instructions

When assessing a Snowflake account for Cost Optimization, follow this structured approach:

### Assessment Methodology
1. **Query the account** using the SQL queries provided in the "Assessment Queries" section
2. **Evaluate each topic** against the criteria in the scoring rubric
3. **Generate findings** in a consistent format: Finding, Impact, Recommendation
4. **Calculate scores** using the scoring rubric (1-5 scale per topic)
5. **Prioritize recommendations** by potential savings and implementation effort

### Output Format
For each assessment, provide:
- **Executive Summary**: Overall score (1-5) with 2-3 sentence summary
- **Topic Scores**: Individual scores for each of the 4 key topics
- **Critical Findings**: Top 3-5 cost optimization opportunities
- **Recommendations**: Actionable items sorted by priority (High/Medium/Low)
- **Quick Wins**: Cost savings that can be achieved within 1 week

### Scoring Guidelines
- **5 (Excellent)**: Fully optimized, comprehensive governance, minimal waste
- **4 (Good)**: Well-optimized, minor improvement opportunities
- **3 (Moderate)**: Adequate cost management, significant savings available
- **2 (Limited)**: Poor cost hygiene, major optimization needed
- **1 (Poor)**: No cost governance, significant waste

### Cost Impact Estimation
When providing recommendations, estimate potential savings:
- **High Impact**: >20% cost reduction potential
- **Medium Impact**: 10-20% cost reduction potential
- **Low Impact**: <10% cost reduction potential

---

## Overview

Cost Optimization focuses on aligning Snowflake spend with business value. In Snowflake's consumption-based model, this pillar emphasizes connecting costs to outcomes, knowing where spend is going, preventing runaway costs, and reducing costs without sacrificing value.

---

## Key Topics

### Business Value

Connect costs to outcomes.

#### ROI Analysis

Understand the business value delivered by each workload relative to its cost.

| Metric | Description | Use Case |
|--------|-------------|----------|
| **Cost per Workload** | Compute + storage costs | Value assessment |
| **Revenue Attribution** | Business outcomes | ROI calculation |
| **Time Savings** | Efficiency gains | Productivity value |
| **Decision Value** | Insights enabled | Business impact |

#### Cost-Benefit Trade-offs

Make informed decisions about performance vs. cost (e.g., larger warehouse for faster queries).

| Trade-off | Consideration | Decision Framework |
|-----------|---------------|-------------------|
| **Speed vs. Cost** | Warehouse size | SLA requirements |
| **Freshness vs. Cost** | Refresh frequency | Business needs |
| **Redundancy vs. Cost** | Replication | Risk tolerance |
| **Features vs. Cost** | Enterprise features | Value delivered |

#### Value Attribution

Tie Snowflake spend to business outcomes (revenue generated, decisions enabled, time saved).

| Attribution | Description | Use Case |
|-------------|-------------|----------|
| **Revenue Impact** | Direct revenue connection | Sales analytics |
| **Cost Avoidance** | Prevented expenses | Operational efficiency |
| **Productivity Gains** | Time savings | Resource optimization |
| **Risk Reduction** | Compliance value | Regulatory requirements |

#### Stakeholder Alignment

Ensure business stakeholders understand and accept the cost of their data requirements.

| Practice | Description | Use Case |
|----------|-------------|----------|
| **Cost Reporting** | Regular updates | Budget awareness |
| **Approval Workflows** | Spending controls | Governance |
| **SLA Agreements** | Performance commitments | Expectation setting |
| **Capacity Planning** | Future needs | Budget forecasting |

**Assessment Criteria:**
- Is ROI tracked for key workloads?
- Are cost-benefit trade-offs documented?
- Is value attribution in place?
- Are stakeholders aligned on costs?

---

### Visibility

Know where your spend is going.

#### Cost Attribution

Use tags and resource monitors to attribute costs to teams, projects, or cost centers.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Object Tagging** | Cost center metadata | Department attribution |
| **Query Tags** | Query-level tracking | Application costs |
| **Warehouse Tags** | Compute attribution | Team allocation |
| **Database Tags** | Storage attribution | Data ownership |

#### Usage Dashboards

Build dashboards from ACCOUNT_USAGE views (WAREHOUSE_METERING_HISTORY, STORAGE_USAGE, etc.).

| View | Description | Use Case |
|------|-------------|----------|
| **METERING_HISTORY** | Overall consumption | Cost trends |
| **WAREHOUSE_METERING_HISTORY** | Compute details | Warehouse analysis |
| **STORAGE_USAGE** | Storage metrics | Data costs |
| **DATA_TRANSFER_HISTORY** | Egress tracking | Transfer costs |

#### Chargeback/Showback

Implement chargeback models to make teams accountable for their consumption.

| Model | Description | Use Case |
|-------|-------------|----------|
| **Chargeback** | Actual billing to teams | Cost accountability |
| **Showback** | Cost visibility without billing | Awareness building |
| **Budget Allocation** | Pre-assigned credits | Spending limits |
| **Cost Alerts** | Threshold notifications | Proactive management |

#### Anomaly Detection

Monitor for unexpected spikes in compute or storage usage.

| Pattern | Description | Action |
|---------|-------------|--------|
| **Sudden Spikes** | Unexpected consumption | Investigate cause |
| **Gradual Growth** | Trending increase | Capacity planning |
| **Unusual Patterns** | Off-hours activity | Security review |
| **New Consumers** | New workloads | Attribution setup |

**Assessment Criteria:**
- Are tags applied for cost attribution?
- Are usage dashboards in place?
- Is there chargeback/showback process?
- Is anomaly detection configured?

---

### Control

Prevent runaway costs.

#### Resource Monitors

Set credit quotas at account, warehouse, or tag level with alerts and auto-suspend actions.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Credit Quota** | Spending limit | Budget enforcement |
| **Frequency** | Reset period | Monthly/Weekly tracking |
| **Triggers** | Action thresholds | Progressive alerts |
| **Actions** | Notify/Suspend | Cost prevention |

#### Warehouse Timeouts

Configure AUTO_SUSPEND (e.g., 60 seconds for interactive, 300+ for batch) to avoid idle compute.

| Workload Type | Recommended Suspend | Rationale |
|---------------|---------------------|-----------|
| **ETL** | 60 seconds | Predictable patterns |
| **BI/Interactive** | 300 seconds | User think time |
| **Ad-hoc** | 120 seconds | Variable patterns |
| **Scheduled** | 60 seconds | Known intervals |

#### Statement Timeouts

Set STATEMENT_TIMEOUT_IN_SECONDS to kill runaway queries.

| Workload Type | Recommended Timeout | Rationale |
|---------------|---------------------|-----------|
| **Interactive** | 300-600 seconds | User expectation |
| **ETL** | 3600+ seconds | Long processing |
| **Ad-hoc** | 900 seconds | Reasonable limit |
| **Scheduled** | Based on SLA | Pipeline needs |

#### Governance Policies

Implement approval workflows for creating new warehouses or increasing sizes.

| Control | Description | Use Case |
|---------|-------------|----------|
| **Warehouse Creation** | Approval required | Proliferation control |
| **Size Changes** | Review process | Cost impact awareness |
| **New Databases** | Storage planning | Growth management |
| **Feature Enablement** | Cost assessment | Enterprise features |

**Assessment Criteria:**
- Are Resource Monitors on all warehouses?
- Is Auto-Suspend configured appropriately?
- Are statement timeouts in place?
- Is there governance for new resources?

---

### Optimization

Reduce costs without sacrificing value.

#### Right-Sizing

Regularly review warehouse utilization and downsize over-provisioned warehouses.

| Analysis | Description | Action |
|----------|-------------|--------|
| **Fast Queries on Large WHs** | Oversized | Downsize |
| **Slow Queries on Small WHs** | Undersized | Upsize |
| **High Queue Time** | Under-scaled | Add clusters |
| **Low Utilization** | Over-provisioned | Reduce |

#### Auto-Suspend Tuning

Balance suspend/resume overhead against idle compute costs.

| Factor | Consideration | Impact |
|--------|---------------|--------|
| **Resume Time** | 1-2 seconds typical | User experience |
| **Idle Credits** | Per-minute cost | Direct savings |
| **Usage Pattern** | Query frequency | Optimal setting |
| **Cache Warm-up** | First query slower | Performance trade-off |

#### Storage Optimization

Use transient tables for staging data, set appropriate DATA_RETENTION_TIME_IN_DAYS.

| Strategy | Description | Savings |
|----------|-------------|---------|
| **Transient Tables** | No Fail-safe | ~30% storage |
| **Reduced Time Travel** | Lower retention | Variable |
| **Clone Cleanup** | Remove old clones | Storage recovery |
| **Stage Cleanup** | Remove old files | Stage costs |

#### Query Efficiency

Optimize expensive queries to reduce compute time (see Performance pillar).

| Optimization | Description | Impact |
|--------------|-------------|--------|
| **Column Pruning** | Select specific columns | Reduced scanning |
| **Filter Pushdown** | Early filtering | Less processing |
| **Clustering** | Data organization | Better pruning |
| **Caching** | Result reuse | Compute savings |

#### Serverless Features

Evaluate Snowpipe, Tasks, and Dynamic Tables for appropriate workloads.

| Feature | Best For | Cost Model |
|---------|----------|------------|
| **Snowpipe** | Continuous loading | Per-file |
| **Serverless Tasks** | Scheduled jobs | Per-execution |
| **Dynamic Tables** | Incremental transforms | Refresh-based |
| **Query Acceleration** | Large scans | On-demand |

**Assessment Criteria:**
- Are warehouses right-sized?
- Is Auto-Suspend optimized?
- Is storage optimized?
- Are serverless features used appropriately?

---

## Cost Structure Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    BUSINESS VALUE LAYER                          │
│      ROI Analysis │ Trade-offs │ Attribution │ Alignment        │
├─────────────────────────────────────────────────────────────────┤
│                    VISIBILITY LAYER                              │
│   Cost Attribution │ Dashboards │ Chargeback │ Anomaly Detection│
├─────────────────────────────────────────────────────────────────┤
│                    CONTROL LAYER                                 │
│  Resource Monitors │ Auto-Suspend │ Timeouts │ Governance       │
├─────────────────────────────────────────────────────────────────┤
│                   OPTIMIZATION LAYER                             │
│   Right-Sizing │ Storage Optimization │ Query Efficiency        │
└─────────────────────────────────────────────────────────────────┘
```

---

## Implementation Patterns

### Resource Monitor Configuration

```sql
CREATE OR REPLACE RESOURCE MONITOR account_monitor
  WITH CREDIT_QUOTA = 10000
  FREQUENCY = MONTHLY
  START_TIMESTAMP = IMMEDIATELY
  TRIGGERS
    ON 75 PERCENT DO NOTIFY
    ON 90 PERCENT DO NOTIFY
    ON 100 PERCENT DO SUSPEND
    ON 110 PERCENT DO SUSPEND_IMMEDIATE;

ALTER ACCOUNT SET RESOURCE_MONITOR = account_monitor;

CREATE OR REPLACE RESOURCE MONITOR etl_monitor
  WITH CREDIT_QUOTA = 2000
  FREQUENCY = WEEKLY
  START_TIMESTAMP = IMMEDIATELY
  TRIGGERS
    ON 80 PERCENT DO NOTIFY
    ON 100 PERCENT DO SUSPEND;

ALTER WAREHOUSE etl_wh SET RESOURCE_MONITOR = etl_monitor;
```

### Cost Attribution with Tags

```sql
CREATE OR REPLACE TAG cost_center ALLOWED_VALUES 'engineering', 'analytics', 'marketing', 'finance';
CREATE OR REPLACE TAG project;
CREATE OR REPLACE TAG environment ALLOWED_VALUES 'dev', 'staging', 'prod';

ALTER WAREHOUSE analytics_wh SET TAG cost_center = 'analytics';
ALTER WAREHOUSE etl_wh SET TAG cost_center = 'engineering', TAG project = 'data_platform';

ALTER DATABASE marketing_db SET TAG cost_center = 'marketing';
```

### Query Tagging

```sql
ALTER SESSION SET QUERY_TAG = 'app=dashboard;team=analytics;env=prod';

SELECT * FROM analytics.daily_metrics;

ALTER SESSION UNSET QUERY_TAG;
```

### Auto-Suspend Optimization

```sql
ALTER WAREHOUSE bi_wh SET AUTO_SUSPEND = 300;

ALTER WAREHOUSE etl_wh SET AUTO_SUSPEND = 60;

ALTER WAREHOUSE adhoc_wh SET AUTO_SUSPEND = 120;

ALTER WAREHOUSE scheduled_wh SET AUTO_SUSPEND = 60;
```

### Time Travel Optimization

```sql
ALTER TABLE staging.temp_data SET DATA_RETENTION_TIME_IN_DAYS = 0;

ALTER TABLE analytics.reports SET DATA_RETENTION_TIME_IN_DAYS = 1;

ALTER TABLE finance.transactions SET DATA_RETENTION_TIME_IN_DAYS = 30;

CREATE TRANSIENT TABLE staging.temp_load (
  id INT,
  data VARIANT
);
```

---

## Assessment Queries

Use these queries to assess the Cost Optimization posture of an account:

### Resource Monitor Status

```sql
SHOW RESOURCE MONITORS;

SELECT 
  name,
  credit_quota,
  used_credits,
  remaining_credits,
  ROUND(used_credits / NULLIF(credit_quota, 0) * 100, 2) as pct_used,
  frequency,
  start_time,
  end_time
FROM snowflake.account_usage.resource_monitors
WHERE end_time > CURRENT_TIMESTAMP()
ORDER BY pct_used DESC;

SELECT 
  warehouse_name
FROM snowflake.account_usage.warehouses
WHERE deleted IS NULL
  AND warehouse_name NOT IN (
    SELECT DISTINCT warehouse_name 
    FROM snowflake.account_usage.warehouse_metering_history
    WHERE resource_monitor IS NOT NULL
  );
```

### Credit Consumption Analysis

```sql
SELECT 
  DATE_TRUNC('day', start_time) as day,
  SUM(credits_used) as total_credits,
  SUM(CASE WHEN service_type = 'WAREHOUSE_METERING' THEN credits_used ELSE 0 END) as warehouse_credits,
  SUM(CASE WHEN service_type = 'CLOUD_SERVICES' THEN credits_used ELSE 0 END) as cloud_credits,
  SUM(CASE WHEN service_type = 'AUTO_CLUSTERING' THEN credits_used ELSE 0 END) as clustering_credits,
  SUM(CASE WHEN service_type = 'SNOWPIPE' THEN credits_used ELSE 0 END) as snowpipe_credits
FROM snowflake.account_usage.metering_history
WHERE start_time > DATEADD(day, -30, CURRENT_TIMESTAMP())
GROUP BY 1
ORDER BY 1;

SELECT 
  warehouse_name,
  SUM(credits_used) as credits,
  ROUND(SUM(credits_used) / (SELECT SUM(credits_used) FROM snowflake.account_usage.warehouse_metering_history WHERE start_time > DATEADD(day, -30, CURRENT_TIMESTAMP())) * 100, 2) as pct_of_total
FROM snowflake.account_usage.warehouse_metering_history
WHERE start_time > DATEADD(day, -30, CURRENT_TIMESTAMP())
GROUP BY 1
ORDER BY credits DESC
LIMIT 10;
```

### Auto-Suspend Analysis

```sql
SELECT 
  warehouse_name,
  warehouse_size,
  auto_suspend,
  auto_resume,
  CASE 
    WHEN auto_suspend IS NULL OR auto_suspend = 0 THEN 'CRITICAL: Never suspends'
    WHEN auto_suspend > 600 THEN 'WARNING: Long suspend time (>10 min)'
    WHEN auto_suspend > 300 THEN 'OK: 5-10 min'
    ELSE 'GOOD: <= 5 min'
  END as suspend_assessment
FROM snowflake.account_usage.warehouses
WHERE deleted IS NULL
ORDER BY auto_suspend DESC NULLS FIRST;
```

### Cloud Services Ratio

```sql
SELECT 
  DATE_TRUNC('day', start_time) as day,
  warehouse_name,
  SUM(credits_used) as compute_credits,
  SUM(credits_used_cloud_services) as cloud_credits,
  ROUND(SUM(credits_used_cloud_services)/NULLIF(SUM(credits_used),0)*100, 2) as cloud_pct
FROM snowflake.account_usage.warehouse_metering_history
WHERE start_time > DATEADD(day, -30, CURRENT_TIMESTAMP())
GROUP BY 1, 2
HAVING cloud_pct > 10
ORDER BY cloud_credits DESC;
```

### Warehouse Right-Sizing

```sql
SELECT 
  warehouse_name,
  warehouse_size,
  COUNT(*) as query_count,
  ROUND(AVG(total_elapsed_time)/1000, 2) as avg_seconds,
  ROUND(AVG(queued_overload_time)/1000, 2) as avg_queue_seconds,
  ROUND(SUM(credits_used_cloud_services), 2) as cloud_credits
FROM snowflake.account_usage.query_history
WHERE start_time > DATEADD(day, -30, CURRENT_TIMESTAMP())
  AND warehouse_name IS NOT NULL
GROUP BY 1, 2
ORDER BY query_count DESC;
```

### Storage Analysis

```sql
SELECT 
  database_name,
  ROUND(SUM(active_bytes)/POWER(1024,4), 4) as active_tb,
  ROUND(SUM(time_travel_bytes)/POWER(1024,4), 4) as time_travel_tb,
  ROUND(SUM(failsafe_bytes)/POWER(1024,4), 4) as failsafe_tb,
  ROUND(SUM(retained_for_clone_bytes)/POWER(1024,4), 4) as clone_tb,
  ROUND((SUM(time_travel_bytes) + SUM(failsafe_bytes) + SUM(retained_for_clone_bytes)) / 
        NULLIF(SUM(active_bytes), 0) * 100, 2) as overhead_pct
FROM snowflake.account_usage.table_storage_metrics
WHERE deleted = FALSE
GROUP BY database_name
ORDER BY active_tb DESC;
```

### Tag Coverage

```sql
SELECT 
  w.warehouse_name,
  t.tag_name,
  t.tag_value
FROM snowflake.account_usage.warehouses w
LEFT JOIN snowflake.account_usage.tag_references t
  ON w.warehouse_id = t.object_id
  AND t.domain = 'WAREHOUSE'
WHERE w.deleted IS NULL
ORDER BY w.warehouse_name;

SELECT 
  warehouse_name
FROM snowflake.account_usage.warehouses w
WHERE deleted IS NULL
  AND NOT EXISTS (
    SELECT 1 FROM snowflake.account_usage.tag_references t
    WHERE t.object_id = w.warehouse_id
      AND t.tag_name = 'COST_CENTER'
  );
```

### Projected Spend

```sql
SELECT 
  ROUND(SUM(credits_used) / DATEDIFF(day, DATE_TRUNC('month', CURRENT_DATE()), CURRENT_DATE()) * DAY(LAST_DAY(CURRENT_DATE())), 2) as projected_monthly_credits,
  ROUND(SUM(credits_used), 2) as mtd_credits,
  DATEDIFF(day, DATE_TRUNC('month', CURRENT_DATE()), CURRENT_DATE()) as days_elapsed
FROM snowflake.account_usage.metering_history
WHERE start_time >= DATE_TRUNC('month', CURRENT_DATE());
```

---

## Scoring Rubric

### Business Value
| Score | Criteria |
|-------|----------|
| 5 | ROI tracked, trade-offs documented, value attributed, stakeholders aligned |
| 4 | Good value tracking, minor gaps |
| 3 | Some value awareness, limited attribution |
| 2 | Minimal value tracking |
| 1 | No value connection to costs |

### Visibility
| Score | Criteria |
|-------|----------|
| 5 | Full tag coverage, dashboards active, chargeback process, anomaly detection |
| 4 | Good visibility, some gaps |
| 3 | Basic visibility, limited attribution |
| 2 | Minimal visibility |
| 1 | No cost visibility |

### Control
| Score | Criteria |
|-------|----------|
| 5 | Resource monitors on all WHs, optimal auto-suspend, timeouts set, governance in place |
| 4 | Good controls, minor gaps |
| 3 | Some controls, inconsistent |
| 2 | Limited controls |
| 1 | No cost controls |

### Optimization
| Score | Criteria |
|-------|----------|
| 5 | Right-sized WHs, optimized storage, efficient queries, serverless adopted |
| 4 | Good optimization, minor opportunities |
| 3 | Some optimization, significant savings available |
| 2 | Limited optimization, waste present |
| 1 | No optimization, significant waste |

---

## Cost Optimization Quick Wins

| Action | Potential Savings | Effort |
|--------|-------------------|--------|
| Reduce Auto-Suspend to 60s | 10-30% compute | Low |
| Right-size warehouses | 20-50% compute | Medium |
| Reduce Time Travel retention | 10-40% storage | Low |
| Use Transient tables for staging | 30-50% storage | Low |
| Drop unused clones | Variable storage | Low |
| Consolidate small warehouses | 10-20% compute | Medium |
| Optimize Cloud Services ratio | 5-15% compute | Medium |
| Use Data Sharing vs ETL | 30-60% overall | High |

---

## Core Principles

- Tag all resources for cost attribution
- Set resource monitors and budgets proactively
- Review and right-size warehouses regularly
- Optimize storage (transient tables, retention policies)

---

## Best Practices Checklist

- [ ] Connect costs to business value and ROI
- [ ] Document cost-benefit trade-offs for key decisions
- [ ] Set up Resource Monitors for all warehouses
- [ ] Configure account-level credit budget
- [ ] Implement cost attribution with Tags
- [ ] Set appropriate Auto-Suspend timers (60-300 seconds)
- [ ] Right-size warehouses based on workload analysis
- [ ] Use Transient tables for staging data
- [ ] Optimize Time Travel retention settings
- [ ] Monitor and clean up unused clones
- [ ] Review Cloud Services ratio (should be < 10%)
- [ ] Use Serverless Tasks instead of dedicated warehouses where appropriate
- [ ] Consider Data Sharing over ETL for data distribution
- [ ] Monitor serverless feature costs regularly
- [ ] Set up cost alerts at 75%, 90%, 100% thresholds
- [ ] Review storage costs monthly
- [ ] Implement query tagging for cost attribution
- [ ] Establish chargeback/showback process

---

## Related Documentation

- [Resource Monitors](https://docs.snowflake.com/en/user-guide/resource-monitors)
- [Cost Management](https://docs.snowflake.com/en/user-guide/cost-management)
- [Understanding Compute Cost](https://docs.snowflake.com/en/user-guide/cost-understanding-compute)
- [Understanding Storage Cost](https://docs.snowflake.com/en/user-guide/cost-understanding-overall)
- [Object Tagging](https://docs.snowflake.com/en/user-guide/object-tagging)
- [Auto-Suspend and Auto-Resume](https://docs.snowflake.com/en/user-guide/warehouses-overview)
