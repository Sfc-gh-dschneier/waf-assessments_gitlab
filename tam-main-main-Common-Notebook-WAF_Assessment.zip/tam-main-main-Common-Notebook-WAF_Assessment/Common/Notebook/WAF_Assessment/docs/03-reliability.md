# Well-Architected Framework: Reliability

## LLM Assessment Instructions

When assessing a Snowflake account for Reliability, follow this structured approach:

### Assessment Methodology
1. **Query the account** using the SQL queries provided in the "Assessment Queries" section
2. **Evaluate each topic** against the criteria in the scoring rubric
3. **Generate findings** in a consistent format: Finding, Impact, Recommendation
4. **Calculate scores** using the scoring rubric (1-5 scale per topic)
5. **Prioritize recommendations** by business continuity impact

### Output Format
For each assessment, provide:
- **Executive Summary**: Overall score (1-5) with 2-3 sentence summary
- **Topic Scores**: Individual scores for each of the 4 key topics
- **Critical Findings**: Top 3-5 reliability risks requiring immediate attention
- **Recommendations**: Actionable items sorted by priority (Critical/High/Medium/Low)
- **Quick Wins**: Reliability improvements that can be implemented within 1 week

### Scoring Guidelines
- **5 (Excellent)**: Full HA/DR implementation, tested failover, self-healing systems
- **4 (Good)**: DR configured, some failover testing, good resilience
- **3 (Moderate)**: Basic resilience, limited DR, single-region
- **2 (Limited)**: Minimal resilience planning, recovery gaps
- **1 (Poor)**: No DR, single points of failure, no recovery capability

### RTO/RPO Context
When assessing, consider:
- **RTO (Recovery Time Objective)**: How quickly must systems recover?
- **RPO (Recovery Point Objective)**: How much data loss is acceptable?
- Match recommendations to the organization's stated requirements

---

## Overview

Reliability focuses on ensuring systems remain available and recover quickly from failures. In Snowflake, this encompasses establishing reliability standards, handling expected failures gracefully, architecting for high availability, and restoring operations quickly after failures.

---

## Key Topics

### Governance

Establish reliability standards and ownership.

#### SLA Definition

Define availability and recovery time objectives (RTO/RPO) for each workload.

| Tier | RTO | RPO | Use Case |
|------|-----|-----|----------|
| **Tier 1 (Critical)** | < 1 hour | < 15 minutes | Revenue-impacting systems |
| **Tier 2 (Important)** | < 4 hours | < 1 hour | Business operations |
| **Tier 3 (Standard)** | < 24 hours | < 4 hours | Internal analytics |
| **Tier 4 (Development)** | Best effort | Best effort | Non-production |

#### Ownership Model

Assign clear ownership for data assets, pipelines, and incident response.

| Aspect | Description | Use Case |
|--------|-------------|----------|
| **Object Tagging** | Ownership metadata | Asset accountability |
| **Role Hierarchy** | Team-based access | Clear responsibility |
| **Documentation** | Runbooks and contacts | Incident response |
| **On-Call Rotation** | Escalation paths | 24/7 coverage |

#### Operational Procedures

Document runbooks for common incidents, escalation paths, and on-call rotations.

| Artifact | Description | Use Case |
|----------|-------------|----------|
| **Runbooks** | Step-by-step procedures | Incident response |
| **Escalation Paths** | Contact hierarchy | Issue resolution |
| **Post-Mortem Templates** | Incident analysis | Continuous improvement |
| **Change Management** | Approval workflows | Production safety |

#### Change Management

Implement approval workflows and rollback procedures for production changes.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Time Travel** | Point-in-time recovery | Rollback capability |
| **Zero-Copy Cloning** | Instant copies | Pre-change backups |
| **Git Integration** | Version control | Change tracking |
| **CI/CD Gates** | Approval workflows | Production protection |

**Assessment Criteria:**
- Are SLAs defined for critical workloads?
- Is there clear ownership for data assets?
- Are operational procedures documented?
- Is change management implemented?

---

### Tolerance

Handle expected failures gracefully.

#### Retry Logic

Implement exponential backoff and retry mechanisms for transient failures.

| Pattern | Description | Use Case |
|---------|-------------|----------|
| **Exponential Backoff** | Increasing delays | Transient error handling |
| **Circuit Breaker** | Fail fast pattern | Cascade prevention |
| **Timeout Configuration** | Query limits | Resource protection |
| **Error Handling** | TRY/CATCH logic | Graceful degradation |

#### Idempotent Operations

Design pipelines that can be safely re-run without duplicating data.

| Pattern | Description | Use Case |
|---------|-------------|----------|
| **MERGE Statements** | Upsert logic | Duplicate prevention |
| **Stream Offsets** | Exactly-once processing | CDC reliability |
| **Transaction Blocks** | Atomic operations | Data consistency |
| **Unique Constraints** | Data integrity | Duplicate detection |

#### Graceful Degradation

Build systems that continue functioning (potentially with reduced capability) when dependencies fail.

| Pattern | Description | Use Case |
|---------|-------------|----------|
| **Fallback Logic** | Alternative paths | Dependency failures |
| **Cached Results** | Stale data serving | Performance issues |
| **Feature Flags** | Selective features | Partial outages |
| **Load Shedding** | Priority processing | Resource constraints |

#### Circuit Breakers

Prevent cascading failures by failing fast when downstream systems are unavailable.

| Pattern | Description | Use Case |
|---------|-------------|----------|
| **Health Checks** | Dependency monitoring | Early detection |
| **Timeout Limits** | Fast failure | Resource protection |
| **Error Thresholds** | Automatic disable | Cascade prevention |
| **Recovery Probes** | Auto re-enable | Service restoration |

**Assessment Criteria:**
- Is retry logic implemented for transient failures?
- Are pipelines designed for idempotent execution?
- Is there graceful degradation for dependency failures?
- Are circuit breaker patterns in use?

---

### Resiliency

Architect for high availability.

#### Multi-Region Deployment

Use database replication and failover groups for cross-region redundancy.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Replication Groups** | Cross-region data sync | Data availability |
| **Failover Groups** | Automatic failover | Regional disaster recovery |
| **Multi-Cloud** | AWS/Azure/GCP support | Cloud redundancy |
| **Connection Redirect** | Automatic rerouting | Transparent failover |

#### Client Redirect

Configure client redirect for automatic failover to secondary regions.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Connection Objects** | Named connections | Failover configuration |
| **Redirect Policy** | Automatic routing | Transparent failover |
| **DNS Configuration** | Endpoint management | Client routing |
| **Application Config** | Connection strings | Client updates |

#### Workload Isolation

Separate critical workloads to prevent resource contention during incidents.

| Pattern | Description | Use Case |
|---------|-------------|----------|
| **Dedicated Warehouses** | Workload separation | Resource isolation |
| **Priority Queuing** | Critical workload priority | SLA protection |
| **Resource Monitors** | Usage limits | Blast radius control |
| **Schema Separation** | Data isolation | Impact limitation |

#### Load Distribution

Use multi-cluster warehouses to distribute query load.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Multi-Cluster Warehouses** | Auto-scaling compute | High concurrency |
| **Scaling Policies** | Standard vs Economy | Load management |
| **Query Acceleration** | Offload processing | Large scan handling |
| **Read Replicas** | Distributed reads | Geographic distribution |

**Assessment Criteria:**
- Is multi-region replication configured?
- Is Client Redirect enabled?
- Are critical workloads isolated?
- Is load distribution implemented?

---

### Recovery

Restore operations quickly after failures.

#### Time Travel

Use Time Travel to recover from accidental data changes.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Point-in-Time Access** | Historical data query | Data investigation |
| **Data Recovery** | Restore previous state | Accidental changes |
| **UNDROP** | Object recovery | Dropped object restoration |
| **Retention Period** | 1-90 days configurable | Recovery window |

#### Fail-safe

Understand Fail-safe as a last-resort recovery option.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **7-Day Window** | Beyond Time Travel | Disaster recovery |
| **Snowflake Support** | Recovery request | Last resort |
| **Read-Only Access** | Data extraction | Recovery scenario |
| **No Self-Service** | Support-assisted | Emergency use only |

#### Backup Strategy

Implement data export or replication strategies for critical data.

| Strategy | Description | Use Case |
|----------|-------------|----------|
| **Replication** | Cross-region copy | DR readiness |
| **Data Export** | External backup | Compliance requirements |
| **Clone Snapshots** | Point-in-time copies | Periodic backups |
| **Stream Archival** | CDC history | Audit trail |

#### Disaster Recovery Testing

Regularly test failover procedures and recovery runbooks.

| Activity | Frequency | Description |
|----------|-----------|-------------|
| **Tabletop Exercise** | Monthly | Procedure review |
| **Failover Test** | Quarterly | DR validation |
| **Full DR Drill** | Annually | Complete simulation |
| **Recovery Timing** | Per test | RTO validation |

**Assessment Criteria:**
- Is Time Travel configured appropriately?
- Is Fail-safe understood and documented?
- Is backup strategy in place?
- Is DR testing conducted regularly?

---

## Reliability Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    GOVERNANCE LAYER                              │
│       SLA Definition │ Ownership │ Procedures │ Change Mgmt     │
├─────────────────────────────────────────────────────────────────┤
│                    TOLERANCE LAYER                               │
│  Retry Logic │ Idempotency │ Graceful Degradation │ Circuits    │
├─────────────────────────────────────────────────────────────────┤
│                   RESILIENCY LAYER                               │
│   Multi-Region │ Client Redirect │ Workload Isolation │ Load    │
├─────────────────────────────────────────────────────────────────┤
│                    RECOVERY LAYER                                │
│   Time Travel │ Fail-safe │ Backup Strategy │ DR Testing        │
└─────────────────────────────────────────────────────────────────┘
```

---

## Implementation Patterns

### Business Continuity Setup

```sql
CREATE REPLICATION GROUP prod_dr_group
  OBJECT_TYPES = DATABASES, SHARES, ROLES, USERS, WAREHOUSES
  ALLOWED_DATABASES = prod_analytics, prod_raw
  ALLOWED_SHARES = customer_share
  ALLOWED_ACCOUNTS = myorg.dr_account
  REPLICATION_SCHEDULE = '10 MINUTE';

-- On DR account
CREATE REPLICATION GROUP prod_dr_group
  AS REPLICA OF myorg.prod_account.prod_dr_group;

ALTER REPLICATION GROUP prod_dr_group REFRESH;
```

### Failover Group Configuration

```sql
CREATE FAILOVER GROUP prod_failover
  OBJECT_TYPES = DATABASES, SHARES
  ALLOWED_DATABASES = prod_analytics
  ALLOWED_ACCOUNTS = myorg.dr_account
  REPLICATION_SCHEDULE = '10 MINUTE';

-- On DR account
CREATE FAILOVER GROUP prod_failover
  AS REPLICA OF myorg.prod_account.prod_failover;

-- Initiate failover when needed
ALTER FAILOVER GROUP prod_failover PRIMARY;
```

### Client Redirect for Transparent Failover

```sql
CREATE CONNECTION primary_conn
  AS REPLICA OF myorg.primary_account.primary_conn;

ALTER CONNECTION primary_conn
  SET FAILOVER_ALLOWED_TO_ACCOUNTS = myorg.dr_account;
```

### Multi-Cluster Warehouse

```sql
CREATE OR REPLACE WAREHOUSE analytics_wh
  WAREHOUSE_SIZE = 'MEDIUM'
  AUTO_SUSPEND = 300
  AUTO_RESUME = TRUE
  MIN_CLUSTER_COUNT = 1
  MAX_CLUSTER_COUNT = 10
  SCALING_POLICY = 'STANDARD'
  INITIALLY_SUSPENDED = TRUE;
```

### Reliable Data Pipeline

```sql
CREATE OR REPLACE STREAM orders_stream ON TABLE raw.orders;

CREATE OR REPLACE TASK process_orders
  WAREHOUSE = etl_wh
  SCHEDULE = '5 MINUTE'
  ALLOW_OVERLAPPING_EXECUTION = FALSE
  USER_TASK_TIMEOUT_MS = 3600000
WHEN
  SYSTEM$STREAM_HAS_DATA('orders_stream')
AS
  CALL process_orders_incremental();

ALTER TASK process_orders RESUME;
```

### Time Travel Recovery

```sql
SELECT * FROM orders AT (TIMESTAMP => '2024-01-15 10:30:00'::TIMESTAMP);

CREATE OR REPLACE TABLE orders AS 
SELECT * FROM orders AT (OFFSET => -3600);

CREATE TABLE orders_restored AS
SELECT * FROM orders BEFORE (STATEMENT => '01a1b2c3-0000-0000-0000-000000000000');

UNDROP TABLE orders;
UNDROP SCHEMA raw_data;
UNDROP DATABASE analytics;
```

---

## Assessment Queries

Use these queries to assess the Reliability posture of an account:

### Replication Configuration

```sql
SHOW REPLICATION GROUPS;

SELECT 
  replication_group_name,
  is_primary,
  primary_account,
  allowed_accounts,
  replication_schedule
FROM snowflake.account_usage.replication_groups
WHERE deleted IS NULL;
```

### Replication Lag Monitoring

```sql
SELECT 
  replication_group_name,
  phase,
  primary_snapshot_timestamp,
  secondary_snapshot_timestamp,
  DATEDIFF(minute, primary_snapshot_timestamp, CURRENT_TIMESTAMP()) as lag_minutes
FROM TABLE(information_schema.replication_group_refresh_progress_by_job());
```

### Time Travel Configuration

```sql
SELECT 
  database_name,
  retention_time,
  CASE 
    WHEN retention_time = 0 THEN 'CRITICAL: No Time Travel'
    WHEN retention_time BETWEEN 1 AND 3 THEN 'WARNING: Low retention'
    WHEN retention_time BETWEEN 4 AND 7 THEN 'OK: Standard retention'
    WHEN retention_time > 7 THEN 'GOOD: Extended retention'
  END as retention_status
FROM snowflake.account_usage.databases
WHERE deleted IS NULL
ORDER BY retention_time ASC;
```

### Multi-Cluster Warehouse Check

```sql
SELECT 
  warehouse_name,
  warehouse_size,
  min_cluster_count,
  max_cluster_count,
  scaling_policy,
  auto_suspend,
  auto_resume
FROM snowflake.account_usage.warehouses
WHERE deleted IS NULL
ORDER BY max_cluster_count DESC;

SELECT 
  warehouse_name,
  warehouse_size
FROM snowflake.account_usage.warehouses
WHERE deleted IS NULL
  AND (max_cluster_count IS NULL OR max_cluster_count = 1)
  AND warehouse_name NOT LIKE 'SYSTEM%';
```

### Warehouse Queue Analysis

```sql
SELECT 
  warehouse_name,
  DATE_TRUNC('hour', start_time) as hour,
  AVG(avg_queued_load) as avg_queue,
  MAX(avg_queued_load) as max_queue,
  AVG(avg_blocked) as avg_blocked
FROM snowflake.account_usage.warehouse_load_history
WHERE start_time > DATEADD(day, -7, CURRENT_TIMESTAMP())
  AND avg_queued_load > 0
GROUP BY warehouse_name, DATE_TRUNC('hour', start_time)
ORDER BY avg_queue DESC
LIMIT 50;
```

### Task Execution Health

```sql
SELECT 
  name,
  state,
  COUNT(*) as execution_count,
  SUM(CASE WHEN state = 'SUCCEEDED' THEN 1 ELSE 0 END) as success_count,
  SUM(CASE WHEN state = 'FAILED' THEN 1 ELSE 0 END) as failure_count,
  ROUND(SUM(CASE WHEN state = 'SUCCEEDED' THEN 1 ELSE 0 END) / 
        NULLIF(COUNT(*), 0) * 100, 2) as success_rate
FROM TABLE(information_schema.task_history(
  scheduled_time_range_start => DATEADD(day, -7, CURRENT_TIMESTAMP())
))
GROUP BY name, state
HAVING failure_count > 0
ORDER BY failure_count DESC;
```

### Stream Health

```sql
SHOW STREAMS;

SELECT 
  stream_catalog,
  stream_schema,
  stream_name,
  source_type,
  stale,
  stale_after
FROM snowflake.account_usage.streams
WHERE deleted IS NULL
  AND stale = TRUE;
```

### Dynamic Table Health

```sql
SELECT 
  database_name,
  schema_name,
  name as dynamic_table_name,
  state,
  refresh_trigger,
  data_timestamp,
  DATEDIFF(minute, data_timestamp, CURRENT_TIMESTAMP()) as lag_minutes
FROM snowflake.account_usage.dynamic_table_refresh_history
WHERE refresh_start_time > DATEADD(day, -1, CURRENT_TIMESTAMP())
  AND state = 'FAILED'
ORDER BY refresh_start_time DESC;
```

### Alert Configuration

```sql
SELECT 
  name,
  state,
  schedule,
  condition
FROM snowflake.account_usage.alerts
WHERE deleted IS NULL
ORDER BY state, name;
```

---

## Scoring Rubric

### Governance
| Score | Criteria |
|-------|----------|
| 5 | SLAs defined for all workloads, clear ownership, documented procedures, change management in place |
| 4 | Most governance practices implemented, minor gaps |
| 3 | Basic governance, some documentation |
| 2 | Limited governance, ad-hoc approach |
| 1 | No governance, no documentation |

### Tolerance
| Score | Criteria |
|-------|----------|
| 5 | Retry logic, idempotent pipelines, graceful degradation, circuit breakers implemented |
| 4 | Most fault tolerance patterns in place |
| 3 | Some fault tolerance, inconsistent implementation |
| 2 | Minimal fault tolerance |
| 1 | No fault tolerance, brittle systems |

### Resiliency
| Score | Criteria |
|-------|----------|
| 5 | Multi-region with failover, client redirect, workload isolation, load distribution |
| 4 | Replication configured, some failover testing |
| 3 | Basic resilience, single region |
| 2 | Minimal resilience planning |
| 1 | No resilience, single points of failure |

### Recovery
| Score | Criteria |
|-------|----------|
| 5 | Time Travel optimized, backup strategy, DR testing quarterly, documented runbooks |
| 4 | Good recovery capability, some testing |
| 3 | Basic Time Travel, no DR testing |
| 2 | Default Time Travel, no recovery planning |
| 1 | Time Travel disabled, no recovery capability |

---

## Recovery Time Objectives (RTO) by Feature

| Feature | Typical RTO | Use Case |
|---------|-------------|----------|
| Time Travel | Seconds-Minutes | Accidental changes |
| Zero-Copy Clone | Seconds | Environment restoration |
| Fail-safe | Hours (Snowflake Support) | Disaster recovery |
| Replication Group | Minutes (based on lag) | Regional failover |
| Failover Group | Minutes | Automatic failover |
| Client Redirect | Seconds | Connection failover |

---

## Core Principles

- Design for failure (assume components will fail)
- Leverage Snowflake's built-in replication and failover
- Test recovery procedures regularly
- Define and monitor against SLAs

---

## Best Practices Checklist

- [ ] Define SLAs (RTO/RPO) for all critical workloads
- [ ] Establish clear ownership for data assets
- [ ] Document operational procedures and runbooks
- [ ] Implement retry logic for transient failures
- [ ] Design idempotent pipelines
- [ ] Configure Time Travel retention appropriate for workloads (1-90 days)
- [ ] Set up Replication Groups for cross-region disaster recovery
- [ ] Implement Failover Groups for critical workloads
- [ ] Use Multi-cluster Warehouses for high-concurrency workloads
- [ ] Configure appropriate Auto-Suspend timers
- [ ] Use Dynamic Tables for declarative, self-healing pipelines
- [ ] Implement Streams and Tasks for reliable incremental processing
- [ ] Test failover procedures quarterly
- [ ] Monitor replication lag with Alerts
- [ ] Configure Client Redirect for transparent failover
- [ ] Set up alerts for pipeline failures

---

## Related Documentation

- [Replication and Failover](https://docs.snowflake.com/en/user-guide/replication-intro)
- [Time Travel](https://docs.snowflake.com/en/user-guide/data-time-travel)
- [Multi-cluster Warehouses](https://docs.snowflake.com/en/user-guide/warehouses-multicluster)
- [Dynamic Tables](https://docs.snowflake.com/en/user-guide/dynamic-tables-intro)
- [Streams and Tasks](https://docs.snowflake.com/en/user-guide/streams)
- [Client Redirect](https://docs.snowflake.com/en/user-guide/client-redirect)
