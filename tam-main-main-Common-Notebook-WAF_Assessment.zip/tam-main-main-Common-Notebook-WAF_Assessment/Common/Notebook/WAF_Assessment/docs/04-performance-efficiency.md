# Well-Architected Framework: Performance

## LLM Assessment Instructions

When assessing a Snowflake account for Performance, follow this structured approach:

### Assessment Methodology
1. **Query the account** using the SQL queries provided in the "Assessment Queries" section
2. **Evaluate each topic** against the criteria in the scoring rubric
3. **Generate findings** in a consistent format: Finding, Impact, Recommendation
4. **Calculate scores** using the scoring rubric (1-5 scale per topic)
5. **Prioritize recommendations** by performance impact and effort

### Output Format
For each assessment, provide:
- **Executive Summary**: Overall score (1-5) with 2-3 sentence summary
- **Topic Scores**: Individual scores for each of the 4 key topics
- **Critical Findings**: Top 3-5 performance issues requiring immediate attention
- **Recommendations**: Actionable items sorted by priority (High/Medium/Low)
- **Quick Wins**: Performance improvements that can be implemented within 1 week

### Scoring Guidelines
- **5 (Excellent)**: Optimized queries, right-sized warehouses, leveraging all platform features
- **4 (Good)**: Good performance, minor optimization opportunities
- **3 (Moderate)**: Adequate performance, significant improvement opportunities
- **2 (Limited)**: Performance issues, major optimization needed
- **1 (Poor)**: Severe performance problems, fundamental changes required

### Performance Metrics to Consider
- Query execution time (p50, p90, p99)
- Partition pruning efficiency
- Cache utilization
- Queue time
- Spillage to disk

---

## Overview

Performance focuses on maximizing efficiency and scaling to meet workload demands. In Snowflake, this pillar emphasizes getting the most out of queries and data, handling growing workloads efficiently, continuously monitoring and tuning performance, and using advanced Snowflake capabilities.

---

## Key Topics

### Maximize

Get the most out of your queries and data.

#### Query Optimization

Write efficient SQL—avoid SELECT *, use appropriate filters, minimize joins on large tables.

| Practice | Description | Impact |
|----------|-------------|--------|
| **Column Projection** | Select only needed columns | Reduced data scanning |
| **Filter Pushdown** | Apply filters early | Fewer rows processed |
| **Join Optimization** | Smaller table first | Reduced memory usage |
| **Avoid Functions on Filters** | Use direct comparisons | Enable pruning |

#### Clustering

Apply clustering keys to large tables (typically 1TB+) that are frequently filtered on specific columns.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Clustering Keys** | Data co-location | Query pattern optimization |
| **Automatic Clustering** | Background maintenance | Self-managing organization |
| **Clustering Depth** | Organization metric | Quality assessment |
| **Re-clustering** | Data reorganization | Performance restoration |

#### Materialized Views

Pre-compute expensive aggregations and joins for frequently-run queries.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Materialized Views** | Pre-computed results | Repeated aggregations |
| **Automatic Refresh** | Background updates | Fresh data |
| **Query Rewrite** | Transparent usage | No code changes |
| **Incremental Refresh** | Efficient updates | Cost optimization |

#### Result Caching

Leverage Snowflake's automatic result cache (24-hour window) for repeated identical queries.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Result Cache** | Query result storage | Repeated queries |
| **24-Hour Window** | Cache duration | Same-day queries |
| **Metadata Cache** | Schema information | DDL operations |
| **Warehouse Cache** | Local SSD storage | Recent data access |

#### Micro-partition Pruning

Structure queries to enable Snowflake to skip irrelevant micro-partitions.

| Practice | Description | Impact |
|----------|-------------|--------|
| **Filter on Clustered Columns** | Use clustering keys | Maximum pruning |
| **Avoid OR Conditions** | Use IN clauses | Better optimization |
| **Date Range Filters** | Time-based pruning | Efficient scans |
| **Partition Statistics** | Monitor scanned vs total | Pruning effectiveness |

**Assessment Criteria:**
- Are queries optimized (no SELECT *, proper filters)?
- Are clustering keys aligned with query patterns?
- Are Materialized Views used for repeated aggregations?
- Is partition pruning effective?

---

### Scale

Handle growing workloads efficiently.

#### Warehouse Sizing

Start with smaller warehouses and scale up based on actual performance needs.

| Size | Use Case | Typical Workload |
|------|----------|------------------|
| **X-Small/Small** | Light queries, development | Ad-hoc analysis |
| **Medium** | Standard workloads | BI dashboards |
| **Large** | Complex transforms | ETL processing |
| **X-Large+** | Heavy compute | Data science, ML |

#### Multi-Cluster Warehouses

Enable auto-scaling for concurrent user workloads (BI dashboards, ad-hoc queries).

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Min/Max Clusters** | Scaling bounds | Capacity control |
| **Standard Mode** | Proactive scaling | Performance priority |
| **Economy Mode** | Reactive scaling | Cost priority |
| **Auto-Suspend** | Idle cluster removal | Cost optimization |

#### Workload Isolation

Use separate warehouses for different workload types (ETL vs. reporting vs. data science).

| Warehouse Type | Use Case | Configuration |
|----------------|----------|---------------|
| **ETL Warehouse** | Data loading | Large, short suspend |
| **BI Warehouse** | Dashboards | Medium, multi-cluster |
| **Ad-hoc Warehouse** | Exploration | Small-Medium, long suspend |
| **DS Warehouse** | Data science | X-Large, manual suspend |

#### Scaling Policies

Configure standard vs. economy scaling modes based on latency requirements.

| Policy | Description | Use Case |
|--------|-------------|----------|
| **Standard** | Add clusters proactively | Low latency priority |
| **Economy** | Add clusters only when queued | Cost priority |
| **Auto-Suspend** | Remove idle clusters | Resource optimization |
| **Auto-Resume** | Start on query | On-demand availability |

**Assessment Criteria:**
- Are warehouses right-sized for workloads?
- Is multi-cluster configured for high concurrency?
- Are workloads isolated appropriately?
- Are scaling policies appropriate?

---

### Improve

Continuously monitor and tune performance.

#### Query Profiling

Use Query Profile in the UI to identify bottlenecks (spilling, exploding joins, partition scans).

| Metric | Description | Action |
|--------|-------------|--------|
| **Spillage** | Data to disk | Increase warehouse size |
| **Exploding Joins** | Row multiplication | Review join logic |
| **Full Scans** | No pruning | Add clustering/filters |
| **Slow Operators** | Bottleneck nodes | Optimize specific operations |

#### QUERY_HISTORY Analysis

Monitor query performance trends using ACCOUNT_USAGE.QUERY_HISTORY.

| Metric | Description | Use Case |
|--------|-------------|----------|
| **Execution Time** | Query duration | Performance baseline |
| **Bytes Scanned** | Data volume | Efficiency tracking |
| **Partitions Scanned** | Pruning effectiveness | Clustering validation |
| **Queue Time** | Wait duration | Capacity planning |

#### Warehouse Utilization

Track warehouse load and queuing using WAREHOUSE_METERING_HISTORY.

| Metric | Description | Use Case |
|--------|-------------|----------|
| **Credits Used** | Compute consumption | Cost tracking |
| **Queue Load** | Concurrency pressure | Scaling decisions |
| **Running Queries** | Active workload | Utilization assessment |
| **Idle Time** | Wasted compute | Suspend optimization |

#### Iterative Tuning

Establish performance baselines and measure improvements systematically.

| Practice | Description | Use Case |
|----------|-------------|----------|
| **Baseline Metrics** | Starting measurements | Comparison reference |
| **A/B Testing** | Before/after comparison | Change validation |
| **Query Tagging** | Workload identification | Trend analysis |
| **Regular Reviews** | Scheduled analysis | Continuous improvement |

**Assessment Criteria:**
- Is Query Profile used for optimization?
- Are query performance trends monitored?
- Is warehouse utilization tracked?
- Is there an iterative tuning process?

---

### Leverage

Use advanced Snowflake capabilities.

#### Search Optimization Service

Enable for point lookup queries on large tables without clustering.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Point Lookups** | Equality searches | High-cardinality columns |
| **Substring Search** | LIKE patterns | Text searching |
| **Geo Searches** | Geographic queries | Location data |
| **Selective Columns** | Targeted optimization | Cost control |

#### Unistore

Use hybrid tables for transactional (OLTP) workloads alongside analytical queries.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Hybrid Tables** | OLTP + OLAP | Transactional workloads |
| **Row-Level Locking** | Concurrent updates | High concurrency |
| **Primary Keys** | Unique constraints | Data integrity |
| **Indexes** | Fast lookups | Point queries |

#### Snowpark

Push compute-intensive transformations (Python, Java, Scala) to Snowflake's compute layer.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **DataFrames** | Programmatic SQL | Complex logic |
| **UDFs** | Custom functions | Business logic |
| **Stored Procedures** | Orchestration | Pipeline management |
| **ML Integration** | Model training | Data science |

#### Dynamic Tables

Simplify incremental pipeline logic with declarative transformation definitions.

| Feature | Description | Use Case |
|---------|-------------|----------|
| **Declarative SQL** | Define target state | Pipeline simplification |
| **Automatic Refresh** | Incremental updates | Self-managing |
| **Target Lag** | Freshness control | SLA management |
| **Dependency Tracking** | Pipeline lineage | Impact analysis |

**Assessment Criteria:**
- Is Search Optimization used for selective queries?
- Are advanced features (Unistore, Snowpark) adopted where appropriate?
- Are Dynamic Tables used for pipelines?
- Is Query Acceleration enabled?

---

## Performance Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    MAXIMIZE LAYER                                │
│  Query Optimization │ Clustering │ MVs │ Caching │ Pruning      │
├─────────────────────────────────────────────────────────────────┤
│                     SCALE LAYER                                  │
│   Warehouse Sizing │ Multi-Cluster │ Workload Isolation         │
├─────────────────────────────────────────────────────────────────┤
│                    IMPROVE LAYER                                 │
│    Query Profile │ QUERY_HISTORY │ Utilization │ Tuning         │
├─────────────────────────────────────────────────────────────────┤
│                    LEVERAGE LAYER                                │
│  Search Optimization │ Unistore │ Snowpark │ Dynamic Tables     │
└─────────────────────────────────────────────────────────────────┘
```

---

## Implementation Patterns

### Clustering for Performance

```sql
SELECT SYSTEM$CLUSTERING_INFORMATION('sales', '(sale_date, region)');

ALTER TABLE sales CLUSTER BY (sale_date, region);

SELECT 
  table_name,
  credits_used,
  num_bytes_reclustered
FROM snowflake.account_usage.automatic_clustering_history
WHERE start_time > DATEADD(day, -7, CURRENT_TIMESTAMP());
```

### Search Optimization Service

```sql
ALTER TABLE customers ADD SEARCH OPTIMIZATION;

ALTER TABLE customers ADD SEARCH OPTIMIZATION 
  ON EQUALITY(customer_id), 
  ON EQUALITY(email);

SHOW TABLES LIKE 'customers';
```

### Query Acceleration Service

```sql
ALTER WAREHOUSE analytics_wh SET 
  ENABLE_QUERY_ACCELERATION = TRUE
  QUERY_ACCELERATION_MAX_SCALE_FACTOR = 8;

SELECT 
  query_id,
  eligible_query_acceleration_time
FROM snowflake.account_usage.query_history
WHERE eligible_query_acceleration_time > 0
  AND start_time > DATEADD(day, -7, CURRENT_TIMESTAMP());
```

### Materialized Views

```sql
CREATE OR REPLACE MATERIALIZED VIEW daily_sales_mv
AS
SELECT 
  DATE_TRUNC('day', sale_date) as sale_day,
  region,
  SUM(amount) as total_sales,
  COUNT(*) as transaction_count
FROM sales
GROUP BY 1, 2;

SHOW MATERIALIZED VIEWS LIKE 'daily_sales_mv';
```

### Warehouse Specialization

```sql
CREATE WAREHOUSE etl_wh
  WAREHOUSE_SIZE = 'LARGE'
  AUTO_SUSPEND = 60
  AUTO_RESUME = TRUE
  INITIALLY_SUSPENDED = TRUE;

CREATE WAREHOUSE bi_wh
  WAREHOUSE_SIZE = 'MEDIUM'
  MIN_CLUSTER_COUNT = 1
  MAX_CLUSTER_COUNT = 6
  SCALING_POLICY = 'STANDARD'
  AUTO_SUSPEND = 300
  AUTO_RESUME = TRUE;

CREATE WAREHOUSE ds_wh
  WAREHOUSE_SIZE = 'XLARGE'
  AUTO_SUSPEND = 120
  AUTO_RESUME = TRUE
  INITIALLY_SUSPENDED = TRUE;
```

### Dynamic Tables

```sql
CREATE OR REPLACE DYNAMIC TABLE daily_metrics
  TARGET_LAG = '1 hour'
  WAREHOUSE = analytics_wh
AS
SELECT
  DATE_TRUNC('day', order_date) as metric_date,
  COUNT(*) as order_count,
  SUM(amount) as total_revenue
FROM orders
GROUP BY 1;
```

---

## Assessment Queries

Use these queries to assess the Performance posture of an account:

### Slow Query Analysis

```sql
SELECT 
  query_id,
  user_name,
  warehouse_name,
  warehouse_size,
  ROUND(total_elapsed_time/1000, 2) as elapsed_seconds,
  ROUND(bytes_scanned/1e9, 2) as gb_scanned,
  ROUND(percentage_scanned_from_cache, 2) as cache_pct,
  partitions_scanned,
  partitions_total,
  ROUND(partitions_scanned/NULLIF(partitions_total,0)*100, 2) as partition_scan_pct,
  LEFT(query_text, 200) as query_preview
FROM snowflake.account_usage.query_history
WHERE start_time > DATEADD(day, -7, CURRENT_TIMESTAMP())
  AND total_elapsed_time > 60000
ORDER BY total_elapsed_time DESC
LIMIT 50;
```

### Partition Pruning Efficiency

```sql
SELECT 
  query_id,
  warehouse_name,
  partitions_scanned,
  partitions_total,
  ROUND(partitions_scanned/NULLIF(partitions_total,0)*100, 2) as scan_pct,
  ROUND(total_elapsed_time/1000, 2) as elapsed_seconds,
  LEFT(query_text, 200) as query_preview
FROM snowflake.account_usage.query_history
WHERE start_time > DATEADD(day, -7, CURRENT_TIMESTAMP())
  AND partitions_total > 100
  AND partitions_scanned/NULLIF(partitions_total,0) > 0.5
ORDER BY partitions_total DESC
LIMIT 50;
```

### Cache Utilization

```sql
SELECT 
  warehouse_name,
  COUNT(*) as query_count,
  ROUND(AVG(percentage_scanned_from_cache), 2) as avg_cache_hit_pct,
  ROUND(SUM(bytes_scanned)/1e12, 2) as tb_scanned,
  ROUND(SUM(bytes_scanned * percentage_scanned_from_cache / 100)/1e12, 2) as tb_from_cache
FROM snowflake.account_usage.query_history
WHERE start_time > DATEADD(day, -7, CURRENT_TIMESTAMP())
  AND warehouse_name IS NOT NULL
GROUP BY warehouse_name
ORDER BY query_count DESC;
```

### Warehouse Queue Analysis

```sql
SELECT 
  warehouse_name,
  DATE_TRUNC('hour', start_time) as hour,
  AVG(avg_queued_load) as avg_queue,
  MAX(avg_queued_load) as max_queue,
  AVG(avg_queued_provisioning) as avg_provisioning_queue
FROM snowflake.account_usage.warehouse_load_history
WHERE start_time > DATEADD(day, -7, CURRENT_TIMESTAMP())
  AND avg_queued_load > 0
GROUP BY warehouse_name, DATE_TRUNC('hour', start_time)
ORDER BY avg_queue DESC
LIMIT 50;
```

### Warehouse Right-Sizing Analysis

```sql
SELECT 
  warehouse_name,
  warehouse_size,
  COUNT(*) as fast_query_count,
  ROUND(AVG(total_elapsed_time)/1000, 2) as avg_seconds
FROM snowflake.account_usage.query_history
WHERE start_time > DATEADD(day, -7, CURRENT_TIMESTAMP())
  AND warehouse_size IN ('LARGE', 'XLARGE', '2XLARGE', '3XLARGE', '4XLARGE')
  AND total_elapsed_time < 5000
GROUP BY warehouse_name, warehouse_size
HAVING COUNT(*) > 100
ORDER BY fast_query_count DESC;

SELECT 
  warehouse_name,
  warehouse_size,
  COUNT(*) as slow_query_count,
  ROUND(AVG(total_elapsed_time)/1000, 2) as avg_seconds
FROM snowflake.account_usage.query_history
WHERE start_time > DATEADD(day, -7, CURRENT_TIMESTAMP())
  AND warehouse_size IN ('XSMALL', 'SMALL')
  AND total_elapsed_time > 60000
GROUP BY warehouse_name, warehouse_size
HAVING COUNT(*) > 10
ORDER BY slow_query_count DESC;
```

### Spillage Analysis

```sql
SELECT 
  query_id,
  warehouse_name,
  warehouse_size,
  ROUND(bytes_spilled_to_local_storage/1e9, 2) as gb_spilled_local,
  ROUND(bytes_spilled_to_remote_storage/1e9, 2) as gb_spilled_remote,
  ROUND(total_elapsed_time/1000, 2) as elapsed_seconds,
  LEFT(query_text, 200) as query_preview
FROM snowflake.account_usage.query_history
WHERE start_time > DATEADD(day, -7, CURRENT_TIMESTAMP())
  AND (bytes_spilled_to_local_storage > 0 OR bytes_spilled_to_remote_storage > 0)
ORDER BY bytes_spilled_to_remote_storage DESC
LIMIT 50;
```

### Clustering Key Effectiveness

```sql
SELECT 
  table_catalog,
  table_schema,
  table_name,
  clustering_key
FROM snowflake.account_usage.tables
WHERE clustering_key IS NOT NULL
  AND deleted IS NULL
ORDER BY table_catalog, table_schema, table_name;
```

### Query Acceleration Eligibility

```sql
SELECT 
  warehouse_name,
  COUNT(*) as eligible_query_count,
  SUM(eligible_query_acceleration_time) as total_eligible_time_ms
FROM snowflake.account_usage.query_history
WHERE start_time > DATEADD(day, -7, CURRENT_TIMESTAMP())
  AND eligible_query_acceleration_time > 0
GROUP BY warehouse_name
ORDER BY total_eligible_time_ms DESC;
```

---

## Scoring Rubric

### Maximize
| Score | Criteria |
|-------|----------|
| 5 | Optimized queries, clustering aligned with patterns, MVs for aggregations, excellent pruning |
| 4 | Good query practices, mostly efficient |
| 3 | Basic optimization, some inefficiencies |
| 2 | Poor query patterns, inefficient scans |
| 1 | No optimization, full table scans common |

### Scale
| Score | Criteria |
|-------|----------|
| 5 | Right-sized warehouses, multi-cluster for concurrency, workload isolation, appropriate policies |
| 4 | Good scaling practices, minor gaps |
| 3 | Basic scaling, some bottlenecks |
| 2 | Poor sizing, frequent queuing |
| 1 | No scaling strategy, constant issues |

### Improve
| Score | Criteria |
|-------|----------|
| 5 | Query Profile used regularly, trends monitored, utilization tracked, iterative tuning |
| 4 | Good monitoring practices |
| 3 | Some monitoring, ad-hoc tuning |
| 2 | Limited monitoring |
| 1 | No performance monitoring |

### Leverage
| Score | Criteria |
|-------|----------|
| 5 | Search Optimization, Dynamic Tables, Query Acceleration, advanced features adopted |
| 4 | Good feature adoption |
| 3 | Some advanced features |
| 2 | Limited feature adoption |
| 1 | No advanced features used |

---

## Performance Anti-Patterns to Avoid

| Anti-Pattern | Impact | Solution |
|--------------|--------|----------|
| SELECT * | Excessive data scanning | Project specific columns |
| Missing clustering | Full table scans | Add clustering keys aligned with filters |
| Over-sized warehouses | Wasted credits | Right-size based on workload |
| No partition pruning | Slow queries | Filter on clustered columns |
| Non-deterministic functions | Cache misses | Use RESULT_SCAN or MVs |
| Too many small files | Load overhead | Consolidate to 100-250 MB |
| Single-row operations | High latency | Batch operations |
| Spillage to remote storage | Slow queries | Increase warehouse size |

---

## Core Principles

- Right-size warehouses for workloads
- Use clustering keys for large tables with selective queries
- Monitor and profile slow queries regularly
- Separate workloads to prevent resource contention

---

## Best Practices Checklist

- [ ] Analyze query patterns before choosing clustering keys
- [ ] Enable Search Optimization for selective point lookups
- [ ] Use Query Acceleration for large ad-hoc scans
- [ ] Create specialized warehouses for different workloads
- [ ] Size files appropriately for bulk loading (100-250 MB)
- [ ] Use Snowpipe for continuous ingestion workloads
- [ ] Leverage result caching (avoid non-deterministic functions)
- [ ] Monitor partition pruning efficiency
- [ ] Use Materialized Views for repeated complex aggregations
- [ ] Implement Dynamic Tables for declarative pipelines
- [ ] Review Query Profile for optimization opportunities
- [ ] Use Cortex AI instead of external ML infrastructure
- [ ] Test warehouse sizing with actual workloads
- [ ] Avoid SELECT * - project only needed columns
- [ ] Use appropriate data types (avoid over-sizing)
- [ ] Address queries with spillage to remote storage

---

## Related Documentation

- [Query Performance](https://docs.snowflake.com/en/user-guide/performance-query)
- [Clustering Keys](https://docs.snowflake.com/en/user-guide/tables-clustering-keys)
- [Search Optimization](https://docs.snowflake.com/en/user-guide/search-optimization-service)
- [Query Acceleration](https://docs.snowflake.com/en/user-guide/query-acceleration-service)
- [Snowpipe](https://docs.snowflake.com/en/user-guide/data-load-snowpipe-intro)
- [Cortex AI](https://docs.snowflake.com/en/user-guide/snowflake-cortex)
- [Materialized Views](https://docs.snowflake.com/en/user-guide/views-materialized)
- [Dynamic Tables](https://docs.snowflake.com/en/user-guide/dynamic-tables-intro)
